# Install CineWeb in Different AI Agents

CineWeb needs no API keys, tokens, or paid services. It is a pure file-based skill.

## Codex

1. Keep the folder name as `cineweb`.
2. Ensure `SKILL.md` is at the root of the folder.
3. `SKILL.md` includes YAML frontmatter for Codex-style skill discovery.
4. Add the full folder to the project or skills directory.
5. Tell Codex: "Use the CineWeb skill. Read SKILL.md first."

## Claude Projects

1. Upload the full `cineweb` folder or ZIP.
2. Add this project instruction:
   "Use CineWeb as the operating system for building cinematic 3D product websites. Read SKILL.md first."

## Cursor / Local Agents

1. Place the folder inside your repo (e.g. `.cursor/skills/cineweb/`).
2. Reference it in your agent instructions: "For 3D product sites, follow the CineWeb skill in .cursor/skills/cineweb/."

## OpenClaw

1. Add the folder to your skills or agent knowledge directory.
2. Register/alias it as `cineweb`.
3. Allow the agent to access the Markdown files and the Python tools.

## Custom file-based agents

1. Copy the folder anywhere the agent can read.
2. Instruct the agent: "When asked to build a cinematic product website, read `cineweb/SKILL.md` first and follow its build sequence."

## Optional: scaffold tool

`tools/scaffold.py` generates a starter single-file HTML with the five scene sections stubbed. Requires Python 3.8+. Run `python3 tools/check_environment.py` to verify.
