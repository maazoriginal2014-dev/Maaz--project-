# CineWeb

**Cinematic 3D product websites, built by your AI agent.**

CineWeb turns any AI agent into a creative developer that builds luxury product launch sites: five-act scroll-driven experiences with a photoreal 3D product at the center — hero reveal, orbit exploration, exploded view, reassembly, and a cinematic lifestyle finale. Everything is modeled procedurally in code and delivered as **one self-contained HTML file**. No build step. No stock. No placeholders.

## What's inside

- `SKILL.md` — the skill brain: identity, hard rules, build sequence, module router
- `core/` — design principles, decision tree, output standards
- `scenes/` — five playbooks, one per act (hero → exploration → exploded → reassembly → finale)
- `build/` — tech stack, materials & lighting, scroll system, mobile, performance
- `copy/` — luxury copywriting and CTA strategy
- `qa/` — WebGL fallback and pre-launch checklist
- `templates/` — project brief and scene-script templates
- `tools/` — `scaffold.py` (generates a starter HTML file) and `check_environment.py`
- `examples/` — a fully worked scene script for a fictional luxury watch site

## Install

See `INSTALL_FOR_AGENTS.md` for Codex, Claude Projects, Cursor, and custom agent setup. No API keys needed — the skill works entirely offline.

## Quick start

Tell your agent: **"Use the CineWeb skill. Read SKILL.md first."** Then answer three questions (product, brand story, target device) and it will plan the five acts before writing a line of code.

## Version

1.0.0 — initial release.
