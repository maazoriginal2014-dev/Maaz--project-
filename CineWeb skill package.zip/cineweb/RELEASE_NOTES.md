# CineWeb Release Notes

## v1.0.0 — Initial release

- New skill: CineWeb, a cinematic 3D product-website builder for AI agents.
- `SKILL.md` with YAML frontmatter, identity, hard rules, build sequence, and module router.
- Five scene playbooks: hero, exploration, exploded view, reassembly, lifestyle finale.
- Five build playbooks: tech stack, materials & lighting, scroll system, responsive/mobile, performance.
- Copy modules: luxury copywriting, CTA strategy.
- QA modules: WebGL fallback, pre-launch checklist.
- Templates: project brief, five-act scene script.
- Tools: `scaffold.py` (starter HTML generator), `check_environment.py`.
- Example: fully worked scene script for a fictional luxury watch site.
- No API keys required. Single-file HTML output. 60fps performance budget.
