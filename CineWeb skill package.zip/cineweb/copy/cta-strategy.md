# Copy — CTA Strategy

One page, one decision. The CTA is the climax the previous four acts were building toward.

## The one-CTA rule

- Exactly ONE primary CTA on the page, in the finale. Secondary links (specs, story) are text links, visually quiet.
- Primary CTA label ≤ 4 words. Ranked options: "Reserve yours" (scarcity, luxury) → "Pre-order now" (launch) → "Find a retailer" (distribution) → "Notify me" (waitlist).
- Never "Submit", "Click here", or "Learn more" as the primary.

## CTA block anatomy

1. Ownership headline (≤ 10 words) — the emotional close.
2. Price line — exact price, or "Price on request" for ultra-luxury. Include the single most reassuring spec beside it (warranty, guarantee).
3. The button — accent fill, 18–20px type, 20px vertical padding, hover: lift 2px + glow.
4. Micro-trust line under the button (≤ 60 chars): "Free insured delivery · 5-year warranty" — kills last-second hesitation.

## What the button does

CineWeb sites end at the decision, not the transaction. The button should:
- Best: link to the real checkout/preorder URL (user provides).
- Good: open a minimal email-capture modal (name + email, one field visible at a time).
- Acceptable: `mailto:` or retailer locator link.
- Never: a dead button. If there's nowhere to go, say so during copy approval and downgrade to "Notify me" with a working email capture.

## Urgency without sleaze

- Allowed: real numbers ("First 500 numbered pieces"), real dates ("Ships March").
- Forbidden: fake countdown timers, fake stock counters, "only 2 left" without data.

## Post-CTA

- Success state matters: after email capture, confirm warmly ("You're on the list. We'll write soon.") — never a bare "Thanks."
- The footer follows with 200–300px breathing room. The decision needs space around it.
