# Copy — Luxury Copywriting

The words must match the visuals. Cheap copy on a cinematic site breaks the spell instantly.

## Voice rules

- **Short.** Headlines ≤ 8 words. Sub-lines ≤ 60 characters. If it needs a comma splice to fit, cut words.
- **Concrete.** Name materials, numbers, and craft: "316L steel", "72-hour reserve", "hand-finished". Vague luxury ("unparalleled excellence") is noise.
- **Confident, never desperate.** No exclamation marks. No "Buy now!!!". Periods, not hype.
- **Second person sparingly.** "Your wrist" beats "the wrist" once per page; more feels like a sales letter.

## The five copy beats (one per act)

1. **Hero:** Name + promise. Formula: `[Brand] [Model].` / `[What it does, beautifully.]` Example: "Meridian One. Time, distilled."
2. **Exploration:** Features as benefits. Formula: `[Feature] → [what it means for you]`. "Sapphire crystal — scratch-proof for a decade of daily wear."
3. **Exploded view:** Craft proof. Part names + one material/spec each. Let the engineering speak.
4. **Reassembly:** The vow. One line about longevity/trust. "Built to be serviced, not replaced."
5. **Finale:** The ownership line + price + CTA. "Own the last watch you'll ever need."

## Spec presentation

- Lead with the 3 specs that differentiate; relegate the rest to a quiet spec list near the footer.
- Numbers need context: "72-hour power reserve" → "72-hour power reserve. Take it off Friday, wear it Monday."
- Never invent specs that would be legally problematic (water resistance, certifications) — mark invented specs as illustrative in your build notes to the user, never on the site.

## Words to avoid

Unprecedented, revolutionary, game-changing, world-class (about yourself), premium (as a noun), luxury (as an adjective for everything), "in a world", "elevate your".

## Draft-then-approve

Always draft all headlines and CTAs as plain text for user approval BEFORE building. Rewriting copy in code is 10x the work.
