# Core — Decision Tree

Route every request to the right playbook before writing code.

## New build requests

- "Build a site for [product]" → full sequence: `onboarding.md` → scene script → copy → `scenes/` in act order.
- "Make it feel more premium" → `core/design-principles.md` + `build/materials-lighting.md` + `copy/luxury-copywriting.md`.
- "Add a product configurator / color picker" → `scenes/exploration.md` (hotspot/variant section).
- "It's laggy / slow" → `build/performance.md` first, then `build/responsive-mobile.md`.
- "Make it work on phones" → `build/responsive-mobile.md`.
- "The copy feels generic" → `copy/luxury-copywriting.md`.
- "Add a buy / reserve button" → `copy/cta-strategy.md` + `scenes/lifestyle-finale.md`.
- "It shows a blank page sometimes" → `qa/webgl-fallback.md`.

## Scene-specific requests

- Hero doesn't impress → `scenes/hero-scene.md` (lighting, headline choreography).
- Exploded view looks messy → `scenes/exploded-view.md` (layer ordering, easing, labels).
- Scroll feels jumpy → `build/scroll-system.md`.
- Product looks flat / plasticky → `build/materials-lighting.md`.

## Scope decisions

- User wants more than 5 acts → allowed, but acts 1–5 keep their order and purpose; extras go between exploration and exploded view.
- User wants multiple products → one hero product per site. Additional products get a simple variant switcher in exploration, not full scenes each.
- User wants e-commerce checkout → out of scope. End at the CTA (reserve/notify/retailer link) per `copy/cta-strategy.md`.
- User wants a multi-page site → out of scope. CineWeb builds single-page cinematic experiences.
