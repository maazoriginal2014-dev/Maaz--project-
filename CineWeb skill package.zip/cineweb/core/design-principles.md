# Core — Cinematic Design Principles

These rules define what "cinematic" means in a CineWeb build. Apply them to every scene.

## Lighting

- **Dark-first.** Scenes live in near-black voids (`#050507` to `#0b0b10`). Darkness is what makes the product glow.
- **Three-point studio setup.** Key light (bright, 45° off-axis), rim light (behind, defines silhouette — the most important light), fill (soft, low intensity, lifts shadows).
- **Rim light is non-negotiable.** Without a strong rim/back light, the product melts into the background. Rim intensity should be 1.5–2x the key.
- **One accent color of light.** A subtle colored light (champagne gold, ice blue, ember orange) gives the scene its identity. Never more than one.

## Palette

- Background: near-black, always.
- Primary accent: one metallic tone (gold, silver, copper) used sparingly — headlines, keylines, CTA.
- Product materials carry the color story; UI chrome stays monochrome.
- Text: warm white (`#f5f2ea`) for headlines, muted gray (`#9a958c`) for body. Never pure white on pure black — it vibrates.

## Typography

- Display: elegant serif (Cormorant Garamond, Playfair Display) for headlines — luxury lives in serifs.
- Body/UI: clean geometric sans (Inter, Manrope).
- Scale contrast: headlines 3–5x body size. Generous letter-spacing on labels/eyebrows (0.2em+).
- Maximum 40 characters per headline line. If it's longer, it's not a headline.

## Motion

- **Ease everything.** Use easeInOutCubic or custom cubic-bezier for UI; critically-damped spring feel (lerp with 0.08–0.12 factor) for 3D motion. Nothing moves linearly except intentional mechanical motion.
- **Stagger, don't blast.** Text and callouts animate in sequence (80–120ms stagger), never all at once.
- **Scroll is the director.** Motion maps to scroll progress, not time — the user controls the pace. Idle motion (slow product rotation, particle drift) runs on time.
- **One hero motion per act.** Each act gets a single signature motion. Two competing motions in one act feels cheap.

## Composition

- Product occupies 50–65% of viewport height in hero. Smaller feels apologetic; larger feels aggressive.
- Negative space is a feature. If a section feels empty, the typography is probably too small, not the layout too bare.
- Depth layering: background particles/bokeh → product → foreground UI text. Three planes minimum.
- The rule of thirds for product placement during exploration; centered only for hero and finale reveals.
