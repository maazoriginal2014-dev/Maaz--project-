# Core — Output Standards

Every CineWeb delivery must meet these. Check against `qa/pre-launch-checklist.md` before shipping.

## File standards

- One HTML file. All CSS in `<style>`, all JS in `<script type="module">`. CDN imports only for the 3D library.
- File must open by double-clicking — no server, no build, no console errors.
- Total size target: under 500KB excluding CDN libraries.

## Visual standards

- 60fps on a mid-range phone during scroll (see `build/performance.md`).
- No linear motion on the product; all product motion eased or lerped.
- Text never overlaps the product awkwardly at any scroll position — test the full scroll range.
- All five acts reachable by scrolling; progress indicator shows current act.

## Copy standards

- Zero lorem ipsum, zero "Lorem", zero "Coming soon", zero empty sections.
- Every headline ≤ 40 characters per line. Every CTA ≤ 4 words.
- Brand name, model name, specs, and price are real invented values when the user doesn't supply them.

## Interaction standards

- Drag-to-orbit works with mouse and touch. Scroll never fights the orbit gesture.
- All interactive elements have visible hover/focus states.
- Reduced-motion: respect `prefers-reduced-motion` — disable idle animation and snap scenes without transitions.

## Fallback standards

- WebGL unavailable → elegant branded fallback page (see `qa/webgl-fallback.md`), never blank.
- CDN unreachable → show a clear message, not a broken page. (Optional: inline a minimal fallback notice.)

## Delivery standards

- Deliver the complete file, not fragments.
- Include a 5-line summary: product, brand, acts implemented, device target, known limitations.
- End with 3 things you'd improve with more time.
