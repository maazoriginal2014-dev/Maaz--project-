# Sample Scene Script — "Meridian One" Luxury Watch (fictional)

A filled example showing what a finished scene script looks like.

---

## Act 1 — Hero

- Product pose: floating, slight 3/4 angle, crown facing right
- Idle motion: 6s/revolution around Y, gentle ±2° bob
- Eyebrow: "INTRODUCING"
- Headline: "Meridian One."
- Sub-line: "Time, distilled to its essence."
- Accent light color: champagne gold
- Particle treatment: 60 slow gold dust motes drifting upward

## Act 2 — Exploration

- Orbit limits: ±140° horizontal, ±25° vertical clamp
- Scroll beats: front dial → three-quarter → crown close-up → caseback
- Hotspots:
  1. Sapphire crystal → "Scratch-proof for a decade of daily wear."
  2. Crown → "Hand-wound. 72 hours per wind."
  3. Exhibition caseback → "Calibre M-01, 27 jewels, on display."
- Text panels:
  - Beat 1: "THE DIAL" / "Midnight, legible." / "Hand-applied indices on a fumé black dial. No date window — nothing to interrupt the symmetry."
  - Beat 2: "THE CASE" / "41mm of intent." / "316L steel, brushed by hand. It catches light; it never shouts."
  - Beat 3: "THE CROWN" / "Wind it. Feel it." / "Forty turns of smooth resistance. This is the ritual smartwatches deleted."
- Variants: steel bracelet / black leather / tan suede (swatches)

## Act 3 — Exploded View

- Layers outside → inside:
  1. Sapphire crystal — 2.1mm, double AR-coated
  2. Bezel — polished 316L steel ring
  3. Dial — fumé black, hand-applied indices
  4. Hands — dauphine, hand-polished
  5. Calibre M-01 — automatic, 27 jewels, 72h reserve
  6. Caseback — exhibition sapphire, engraved rotor
- Explode axis: vertical (Y), total spread 1.5x watch height
- Camera: pull back 18%, slow ±10° drift

## Act 4 — Reassembly

- Assembly order: caseback → calibre → hands → dial → bezel → crystal
- Completion pulse: gold ring expands from center + rim light lift 120ms
- Vow headline: "Built to be serviced, not replaced."

## Act 5 — Lifestyle Finale

- Environment: rain-streaked window, warm interior bokeh behind
- Product "in use": on a wrist resting near the window, cuff slightly visible
- Ownership headline: "Own the last watch you'll ever need."
- Price: $2,400 — "5-year warranty · free insured delivery"
- Primary CTA: "Reserve yours" → preorder URL
- Footer: Story / Specs / Journal / Contact / © Meridian

---

## Approval

- [x] User approved scene script
- [x] User approved copy drafts
- [x] Proceed to scaffold
