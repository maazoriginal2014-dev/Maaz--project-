# CineWeb Onboarding — First-Run Questions

Ask these on first use. Maximum three questions — never stall the build waiting for perfect inputs. If the user skips one, invent a sensible answer and note it briefly (never inside the site).

## Question 1 — The product

"What product is the site for? A sentence is enough — e.g. 'wireless earbuds', 'mechanical watch', 'espresso machine'."

If they give a photo or description, extract: product category, standout physical features (materials, signature details), approximate size.

## Question 2 — The brand story

"What should the site make people feel? Luxury? Power? Playfulness? And is there a brand name, or should I invent one?"

Record: emotional tone (pick one primary), brand name (theirs or invented — mark invented), one-line brand promise.

## Question 3 — The audience device

"Will most visitors be on phone or desktop?"

Record: primary device. This sets the performance budget and whether touch orbit leads the interaction design.

## After onboarding

1. Fill `templates/project-brief-template.md` with the answers.
2. Write the scene script (`templates/scene-script-template.md`) and show it to the user for approval before coding.
3. Draft headlines and CTAs (`copy/luxury-copywriting.md`) in text form for approval.
4. Only then scaffold and build.
