# QA — Pre-Launch Checklist

Run this entire list before delivering. Fix failures; don't ship around them.

## File

- [ ] Single HTML file opens by double-click, no server needed
- [ ] Zero console errors and zero console warnings
- [ ] Total file size under 500KB (excluding CDN)
- [ ] Three.js version pinned in the import URL

## All five acts

- [ ] Hero: product visible before headline; scroll cue present; idle rotation calm
- [ ] Exploration: drag orbits on mouse AND touch; hotspots hide on far side; max 5 hotspots
- [ ] Exploded view: layers separate along one axis, staggered; labels don't overlap; end state exact
- [ ] Reassembly: layers snap to exact origin; completion pulse fires; headline lands on the beat
- [ ] Finale: environment crossfades in; ONE primary CTA; price present; footer breathing room

## Scroll

- [ ] Full scroll range tested top to bottom — no text/product collisions at any position
- [ ] Act transitions have settled handoff states (no jumps between acts)
- [ ] Act indicator highlights correctly; clicking dots navigates
- [ ] Resize recomputes section offsets (test at 3 widths)

## Copy

- [ ] Zero lorem ipsum / placeholder / "coming soon"
- [ ] Every headline ≤ 40 chars per line; every CTA ≤ 4 words
- [ ] Brand, model, specs, price all present (invented values noted to user, not on site)

## Performance

- [ ] 60fps during scroll on target device (`?debug` flag shows FPS)
- [ ] Mobile cuts applied (no bloom, halved particles, DPR ≤ 2)
- [ ] Loader fades only after first frame renders

## Fallback & accessibility

- [ ] WebGL disabled → elegant fallback page, not blank
- [ ] `prefers-reduced-motion` disables idle animation
- [ ] All interactive elements keyboard-focusable with visible focus states
- [ ] Color contrast on body text ≥ 4.5:1

## Delivery

- [ ] 5-line summary written (product, brand, acts, device target, limitations)
- [ ] 3 future improvements listed
