# QA — WebGL Fallback

Some users have no WebGL (old devices, strict corporate browsers, disabled hardware acceleration). They must still get a beautiful page — never a blank canvas.

## Detection

```js
function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch (e) { return false; }
}
```

Run BEFORE creating the renderer. If false → show fallback, skip all 3D init.

## The fallback page

Same brand, same story, zero 3D:
- Hero: brand name + promise + a CSS-gradient "product glow" panel (radial gradients suggesting the product's silhouette — abstract, elegant).
- The five acts become five stacked content sections with the same headlines, copy, and spec lists.
- Exploded view becomes a numbered list of layers with their descriptions.
- CTA block identical to the 3D version.
- Styling: same palette, same typography, same dark luxury feel. A fallback user should feel they got the premium site, not the broken one.

## Implementation pattern

```html
<canvas id="scene"></canvas>
<div id="fallback" hidden>…full static content…</div>
```

```js
if (!webglAvailable()) {
  document.getElementById('scene').remove();
  const f = document.getElementById('fallback');
  f.hidden = false;
  document.body.classList.add('no-webgl');
  // no further 3D init
}
```

## Also handle

- **CDN failure:** wrap the Three.js import in try/catch (dynamic `import()`). On failure, show the fallback with a small note. A broken import must never equal a blank page.
- **Context loss:** listen for `webglcontextlost` on the canvas → show fallback with a "reload" suggestion.
- Test by disabling hardware acceleration in browser settings, not just by code inspection.
