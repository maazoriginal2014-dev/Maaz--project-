# Act 3 — Exploded View

The engineering moment. The product comes apart and the user sees the craft inside. This act sells quality.

## Layer planning

- Decompose the product into 5–9 layers, ordered outside → inside (e.g. watch: crystal → bezel → dial → hands → movement → caseback).
- Each layer gets: a name, a one-line description, and an explode direction (usually along one axis, alternating slight offsets for readability).
- Plan layers during the scene-script phase — changing them in code is expensive.

## Scroll choreography

- Map scroll progress 0→1 across the act to layer separation 0→1.
- Separation distances: outer layers travel furthest (1.2–1.6x product height total spread). Inner layers barely move — contrast sells the effect.
- Easing: easeInOutCubic on the master progress, but stagger each layer's start (layer i starts at i×0.06 progress). The cascade reads as mechanical precision.
- Slight rotation continues during explosion (30% of hero speed) so layers catch the light as they separate.

## Labels

- Each layer gets a thin leader line from the layer to a text label at the screen edge.
- Labels fade in staggered, only after their layer has moved 40%+ — no labels on a closed product.
- Label content: part name + one spec or material note (e.g. "Sapphire crystal — 2.1mm, AR-coated").
- On mobile, show labels for the 3 hero layers only; list the rest in a static legend below.

## Camera

- Pull back 15–20% as explosion progresses to keep all layers in frame.
- Slight orbital drift (slow, ±10°) adds parallax between layers.

## Common mistakes

- Exploding along random axes — pick ONE primary axis; chaos reads as broken.
- All layers moving at once — stagger is what makes it feel engineered.
- Labels overlapping each other — sort labels by screen Y and enforce minimum 48px gaps.
- Forgetting to un-explode cleanly — the end state of this act must be the exact start state of reassembly.
