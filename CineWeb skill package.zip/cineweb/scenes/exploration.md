# Act 2 — Exploration (Orbit + Hotspots)

The user takes control. This act converts curiosity into desire through touch.

## Orbit interaction

- Drag (mouse or touch) orbits the product horizontally; vertical drag tilts within ±25° clamped — never let the user lose the product.
- Inertia: on release, rotation continues with decay (friction ~0.95/frame). Feels physical.
- Scroll advances the act; orbit is independent. While dragging, pause idle rotation; resume 2s after release.
- Cursor: grab/grabbing states on desktop. On touch, a one-time hint ("Drag to explore") that fades after first interaction.

## Scroll choreography

- Scroll rotates the product to present its best faces in sequence (front → three-quarter → profile → back detail), each "beat" synced to a text panel.
- Camera stays at fixed distance; the product does the moving.

## Hotspot callouts

- 3–5 hotspots maximum. Each is a pulsing dot anchored to a 3D point on the product, projected to screen space each frame.
- Hotspot activates when its anchor faces the camera (dot product of anchor normal and camera direction > 0.3) — hotspots on the far side hide automatically.
- Clicking/tapping a hotspot opens a small card: feature name (≤ 4 words), one-line benefit (≤ 80 chars), and a spec if relevant.
- Only one card open at a time. Cards dismiss on orbit drag.

## Text panels

- Left or right rail (desktop), bottom sheet (mobile). Each panel: eyebrow, headline (≤ 32 chars), 1–2 sentence body.
- Panels crossfade as scroll beats advance — never stack.

## Variant switcher (optional)

- If the product has colors/materials variants, add 3–4 swatches here. Switching lerps material colors over 0.6s — never an instant pop.
- Keep variant count low; each variant multiplies the materials QA work.

## Common mistakes

- Too many hotspots — 5+ feels like a manual, not a moment.
- Hotspot cards with paragraphs — one line or it doesn't get read.
- Orbit with no limits — users flip the product upside down and get confused.
- Scroll and drag fighting — lock scroll-driven rotation while the user is actively dragging.
