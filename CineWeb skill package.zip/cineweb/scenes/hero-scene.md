# Act 1 — Hero Scene

The first impression. The user should feel the product's presence before reading a word.

## Composition

- Product centered, floating in a dark studio void, occupying 55–65% of viewport height.
- Slow idle rotation (4–8 seconds per revolution) — alive but calm.
- Camera slightly below product eye-level, looking up a touch. Looking up at a product reads as premium; looking down reads as catalog.

## Lighting

- Strong rim light from behind-left (the silhouette edge is the money shot).
- Soft key from front-right at 60% rim intensity.
- One colored accent light from below or side, very subtle (gold for luxury, ice blue for tech).
- Volumetric-feel: 40–80 slow-drifting dust particles catching the rim light. Cheap to render, huge atmosphere payoff.

## Headline choreography

Sequence on load (total ~2.5s):
1. **0.0s** — eyebrow label fades in (e.g. "INTRODUCING", letter-spaced, small).
2. **0.4s** — product/brand name rises with a 24px upward drift + fade (the hero moment).
3. **0.9s** — one-line promise fades in below (≤ 60 characters).
4. **1.4s** — scroll cue appears (animated line or "Scroll" text with gentle bounce).
5. Product scales from 0.94 → 1.0 over the same window — a subtle "arrival".

Never show headline before the product is visible. The product is the headline's stage.

## Scroll behavior

- First 15% of scroll: camera pushes in slightly (dolly 1.0 → 0.85 distance), product rotation eases to a stop.
- Headline elements parallax out at different rates (eyebrow fastest, name slowest) — depth on exit.
- By 20% scroll, hero text is gone and Act 2 begins. Clean handoff, no overlap.

## Common mistakes

- Starting rotation too fast — reads as nervous, not premium.
- Headline covering the product — offset text to lower third or side.
- No scroll cue — 30%+ of users won't know to scroll without one.
- Loading the 3D scene visibly (pop-in) — fade the canvas in only after first frame renders.
