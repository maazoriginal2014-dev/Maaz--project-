# Act 5 — Lifestyle Finale + CTA

The dream moment. The product leaves the studio void and enters a world — then asks for the sale.

## The pull-back

- Camera pulls back and the void crossfades into a cinematic environment: rain-streaked window with city bokeh, sunlit desk, misty mountain ridge — pick ONE environment that matches the brand story.
- Build the environment procedurally too: gradient sky dome, bokeh sprites (cheap: additive-blended circles), simple ground plane with fog. Keep it impressionistic — bokeh and fog hide low geometry budgets.
- The product is now "in use": on a wrist, on a desk, in a hand (suggest with simple context geometry, never a full human model).

## Pacing

- This act is slower. Give the environment 2–3 seconds of scroll to establish before any text appears.
- Product does a final slow turntable (50% hero speed) — the last look.

## CTA block

- Headline: the ownership promise (≤ 10 words, e.g. "Own the last watch you'll ever need.").
- Price + key spec line, then ONE primary CTA button (≤ 4 words: "Reserve yours", "Pre-order now", "Find a retailer").
- Optional secondary link (tech specs, story) — de-emphasized, never competing.
- CTA button: accent color fill, generous padding, hover lift + glow. It should feel like the climax of the page, because it is.

## Footer

- Minimal: brand mark, 3–5 links, copyright. Dark, quiet. The finale's afterglow, not a sitemap.

## End-of-page behavior

- Past the CTA, allow slight overscroll bounce but no more content — the page ends on the decision.
- Optional: a subtle "back to top" that replays the hero. Nice touch, low cost.

## Common mistakes

- Two competing CTAs — one decision per page.
- Environment more detailed than the product — the product must stay the visual hero; environment is atmosphere.
- Ending abruptly after the CTA — the footer needs 200–300px of breathing room so the CTA doesn't feel slammed against the page end.
- Forgetting the price — luxury can say "Price on request", but never leave the user guessing whether they can buy it.
