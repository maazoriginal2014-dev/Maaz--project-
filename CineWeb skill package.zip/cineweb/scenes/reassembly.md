# Act 4 — Reassembly

The satisfaction moment. The product snaps back together with mechanical precision. This act sells reliability.

## Choreography

- Reverse of the exploded view, but NOT a mirror — reassembly should feel more decisive: layers return in inside → outside order (reverse of explosion), each with a slight overshoot-and-settle (easeOutBack, overshoot ~1.05).
- Stagger tighter than explosion (i×0.04) — assembly is faster and more confident than disassembly.
- Scroll maps 0→1 to assembly progress. At 100%, all layers are exactly at origin — verify with a snap-to-zero at progress ≥ 0.995.

## The completion pulse

- The signature beat of this act: when the final layer seats, trigger a pulse — a quick expanding ring of light from the product center + a 120ms brightness lift on the rim light.
- Pair with the headline arriving: the product's core promise in ≤ 8 words (e.g. "Engineered to outlast. Guaranteed for life.").
- This is the emotional peak of the site. Don't waste it on a spec sheet.

## Sound-adjacent motion

- No audio (autoplay policies), but motion should *imply* the click: a 2-frame scale punch (1.0 → 1.015 → 1.0) on each layer as it seats sells the mechanical "snap" visually.

## Camera

- Push in 10% during assembly — the product coming toward the viewer feels like it's being handed to them.
- End framing must match the lifestyle finale's opening framing for a seamless cut.

## Common mistakes

- Assembly at the same speed as explosion — it should feel quicker and more certain.
- No completion beat — without the pulse, the act just... ends. The pulse is the point.
- Layers not quite aligning at the end — floating-point drift is visible on close inspection; snap to exact origin.
- Putting body copy here — this act is visceral, not verbal. One headline, then move on.
