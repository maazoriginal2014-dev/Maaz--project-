# CineWeb Setup — Folder Map and Read Order

## Folder map

```text
cineweb/
├── SKILL.md                  ← start here (identity, rules, router)
├── _meta.json                ← package metadata
├── MANIFEST.json             ← exact file registry
├── README.md                 ← human overview
├── INSTALL_FOR_AGENTS.md     ← per-agent install steps
├── RELEASE_NOTES.md          ← version history
├── onboarding.md             ← first-run questions
├── setup.md                  ← this file
├── core/                     ← design rules and decision logic
│   ├── design-principles.md
│   ├── decision-tree.md
│   └── output-standards.md
├── scenes/                   ← the five acts, in order
│   ├── hero-scene.md
│   ├── exploration.md
│   ├── exploded-view.md
│   ├── reassembly.md
│   └── lifestyle-finale.md
├── build/                    ← engineering playbooks
│   ├── tech-stack.md
│   ├── materials-lighting.md
│   ├── scroll-system.md
│   ├── responsive-mobile.md
│   └── performance.md
├── copy/                     ← words that sell
│   ├── luxury-copywriting.md
│   └── cta-strategy.md
├── qa/                       ← shipping safely
│   ├── webgl-fallback.md
│   └── pre-launch-checklist.md
├── templates/                ← reusable blanks
│   ├── project-brief-template.md
│   └── scene-script-template.md
├── tools/                    ← python helpers
│   ├── check_environment.py
│   └── scaffold.py
└── examples/
    └── sample-scene-script.md
```

## Read order for a new build

1. `SKILL.md` — identity, hard rules, build sequence
2. `onboarding.md` — ask the three questions
3. `core/design-principles.md` + `core/output-standards.md` — lock the visual bar
4. `templates/scene-script-template.md` → write the script → get approval
5. `copy/luxury-copywriting.md` → draft copy → get approval
6. `scenes/*.md` in act order while implementing
7. `build/*.md` as engineering questions arise
8. `qa/pre-launch-checklist.md` before delivery

## Read order for a fix or variation

Use `core/decision-tree.md` to jump straight to the relevant playbook.
