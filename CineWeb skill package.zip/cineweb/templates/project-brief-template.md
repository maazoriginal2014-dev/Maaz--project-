# Project Brief — CineWeb Build

Fill this during onboarding, before writing the scene script.

## Product

- Product name/category:
- Standout physical features (materials, signature details):
- Approximate size:
- Variants (colors/materials, if any):

## Brand

- Brand name (theirs or invented — mark which):
- One-line brand promise:
- Emotional tone (one primary: luxury / power / playfulness / precision / warmth):

## Audience & device

- Primary device (phone / desktop):
- Target customer in one sentence:

## Copy (draft headlines for approval)

- Hero eyebrow:
- Hero headline:
- Hero sub-line:
- Reassembly vow (≤ 8 words):
- Finale ownership line (≤ 10 words):
- Price:
- Primary CTA label (≤ 4 words):
- Micro-trust line:

## Scene notes

- Environment for finale (rain window / sunlit desk / mountain / other):
- Accent light color:
- Hotspots (3–5): feature → benefit lines:
  1.
  2.
  3.
- Exploded layers (5–9, outside → inside):
  1.
  2.
  3.

## Constraints

- Known limitations / invented values (note here, never on the site):
