# Scene Script Template — Five Acts

Write this and get user approval BEFORE coding. One page per act.

---

## Act 1 — Hero

- Product pose:
- Idle motion (speed, axis):
- Eyebrow / headline / sub-line:
- Accent light color:
- Particle treatment:

## Act 2 — Exploration

- Orbit limits (horizontal range, vertical clamp):
- Scroll beats (face sequence):
- Hotspots (anchor point → card content):
  1.
  2.
  3.
- Text panels (per beat — eyebrow / headline / body):
- Variants (if any):

## Act 3 — Exploded View

- Layers outside → inside (name + one-line description each):
  1.
  2.
  3.
- Explode axis + total spread:
- Label content per layer (part + spec):
- Camera move during explosion:

## Act 4 — Reassembly

- Assembly order (inside → outside):
- Completion pulse description:
- Vow headline (≤ 8 words):

## Act 5 — Lifestyle Finale

- Environment description:
- Product "in use" context:
- Ownership headline (≤ 10 words):
- Price + trust line:
- Primary CTA label + destination:
- Footer links (3–5):

---

## Approval

- [ ] User approved scene script
- [ ] User approved copy drafts
- [ ] Proceed to scaffold
