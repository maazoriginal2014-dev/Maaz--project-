#!/usr/bin/env python3
"""CineWeb environment check. Verifies Python is new enough to run the skill tools."""
import sys


def main():
    ok = sys.version_info >= (3, 8)
    print(f"Python {sys.version.split()[0]} — {'PASS' if ok else 'FAIL: need 3.8+'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
