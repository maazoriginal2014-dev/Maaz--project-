#!/usr/bin/env python3
"""CineWeb scaffold generator.

Generates a starter single-file HTML with the five scene sections stubbed
and TODO markers where the agent implements each act.

Usage:
    python3 scaffold.py --brand "Meridian" --product "Meridian One" -o site.html
"""
import argparse
import sys

THREE_VERSION = "0.160.0"

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{brand} — {product}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<style>
  /* TODO: palette, typography, layout per core/design-principles.md */
  :root {{ --bg: #07070a; --ink: #f5f2ea; --muted: #9a958c; --accent: #c9a86a; }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ background: var(--bg); color: var(--ink); font-family: Inter, sans-serif; }}
  #scene {{ position: fixed; inset: 0; width: 100%; height: 100%; display: block; }}
  main section {{ position: relative; min-height: 100vh; z-index: 1; }}
  .eyebrow {{ letter-spacing: .25em; font-size: 12px; color: var(--muted); }}
  h1, h2 {{ font-family: 'Cormorant Garamond', serif; font-weight: 600; }}
</style>
</head>
<body>
<canvas id="scene"></canvas>
<div id="fallback" hidden>
  <!-- TODO: static fallback content per qa/webgl-fallback.md -->
  <h1>{brand} — {product}</h1>
  <p>Your browser does not support WebGL. The full cinematic experience needs it.</p>
</div>
<main>
  <section id="act-1"><!-- TODO: hero per scenes/hero-scene.md --></section>
  <section id="act-2"><!-- TODO: exploration per scenes/exploration.md --></section>
  <section id="act-3"><!-- TODO: exploded view per scenes/exploded-view.md --></section>
  <section id="act-4"><!-- TODO: reassembly per scenes/reassembly.md --></section>
  <section id="act-5"><!-- TODO: finale + CTA per scenes/lifestyle-finale.md --></section>
</main>
<div id="ui">
  <!-- TODO: hotspot cards, act indicator, CTA per copy/cta-strategy.md -->
</div>
<script type="module">
import * as THREE from 'https://unpkg.com/three@{ver}/build/three.module.js';

// TODO: 1. WebGL check (qa/webgl-fallback.md) — show #fallback and stop if unavailable
// TODO: 2. renderer (ACES tone mapping), scene, camera, lights (build/materials-lighting.md)
// TODO: 3. buildProduct() -> {{ group, layers[], hotspots[] }} — procedural only (build/tech-stack.md)
// TODO: 4. buildEnvironment() — gradient dome + bokeh sprites + fog
// TODO: 5. scroll system: per-act progress, current/target lerp (build/scroll-system.md)
// TODO: 6. custom orbit controls: drag to orbit, clamped tilt, inertia
// TODO: 7. animation loop: update lerps, project hotspots, render
// TODO: 8. mobile cuts via matchMedia (build/responsive-mobile.md)
// TODO: 9. ?debug flag: FPS + draw calls + triangles (build/performance.md)

console.log('CineWeb scaffold ready — implement the TODOs act by act.');
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser(description="Generate a CineWeb starter HTML scaffold.")
    ap.add_argument("--brand", default="Brand", help="Brand name")
    ap.add_argument("--product", default="Product", help="Product/model name")
    ap.add_argument("-o", "--output", default="cineweb-site.html", help="Output file")
    args = ap.parse_args()
    html = HTML.format(brand=args.brand, product=args.product, ver=THREE_VERSION)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Scaffold written to {args.output} ({len(html)} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
