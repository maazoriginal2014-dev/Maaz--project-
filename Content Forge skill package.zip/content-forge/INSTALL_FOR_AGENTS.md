# Install Content Forge in Different AI Agents

No API keys or tokens are needed. Content Forge is fully file-based.

## Codex

1. Keep the folder name as `content-forge`.
2. Ensure `SKILL.md` is at the root of the folder.
3. `SKILL.md` includes YAML frontmatter for Codex-style skill discovery.
4. Add the full folder to the project or skills directory.
5. Tell Codex: "Use the Content Forge skill. Read SKILL.md first."

## Claude Projects

1. Upload the full `content-forge` folder or ZIP.
2. Add this project instruction:
   "Use Content Forge as the operating system for content pillars, 30-day calendars, hooks, short-form and long-form scripts, repurposing, and platform tactics. Read SKILL.md first."

## OpenClaw

1. Add the folder to your skills or agent knowledge directory.
2. Register/alias it as `content-forge`.
3. Allow the agent to access the Markdown files and optional Python tools.

## Cursor / Local Agents

1. Place the folder inside your repo.
2. Open `SKILL.md`.
3. Use the supporting modules as task-specific SOPs.
4. Install nothing — Python tools are optional.

## Optional Python Tools

The `tools/` folder has two utilities (environment check, spoken-duration word counter).
They need Python 3.8+ and no third-party packages:

```bash
cd content-forge/tools
python3 check_environment.py
python3 word_counter.py --words 150
```

## Verify the Install

1. `SKILL.md` has valid YAML frontmatter between `---` markers.
2. `MANIFEST.json` lists every file in the folder.
3. The agent can answer: "What are the 5 content pillars?" by reading `pillars/pillar-builder.md`.
