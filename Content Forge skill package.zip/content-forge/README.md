# Content Forge v1.0.0

A portable AI-agent skill that builds complete content systems: pillars, 30-day calendars, hooks, scripts, repurposing, and platform playbooks.

## What it does

- **Pillars** — turns any niche into 5 strategic content pillars (2 reach, 2 trust, 1 conversion)
- **Calendars** — day-by-day 30-day posting plans with rotation rules
- **Hooks** — 8 proven hook formulas with examples
- **Scripts** — short-form (15s/30s/60s) and long-form YouTube scripts with real word budgets
- **Repurposing** — turns 1 piece of content into 10+ platform-native outputs
- **Platforms** — native tactics for TikTok/Reels, YouTube, LinkedIn, X/Threads
- **Tools** — Python utilities: environment check, spoken-duration word counter

## Folder map

```text
content-forge/
├── SKILL.md                  ← start here (agent entry point)
├── README.md
├── INSTALL_FOR_AGENTS.md
├── RELEASE_NOTES.md
├── _meta.json
├── MANIFEST.json
├── onboarding.md             ← first-run questions
├── setup.md                  ← folder map + read order
├── core/                     ← voice rules, decision tree, output standards
├── pillars/                  ← pillar builder
├── calendar/                 ← 30-day calendar engine
├── hooks/                    ← hook formulas
├── scripts/                  ← short-form + long-form script writers
├── repurpose/                ← repurposing engine
├── platform/                 ← tiktok-reels, youtube, linkedin, x-threads
├── templates/                ← blank calendar CSV, script + hook templates
├── tools/                    ← check_environment.py, word_counter.py
└── examples/                 ← filled-in sample calendar (fitness coach)
```

## Quick start

1. Install per `INSTALL_FOR_AGENTS.md` (no API keys needed).
2. Tell your agent: "Use the Content Forge skill. Read SKILL.md first."
3. Answer 3 questions: niche, audience, platform.
4. Get pillars → calendar → hooks → scripts, in that order.

## Requirements

- Any file-based AI agent (Codex, Claude Projects, Cursor, OpenClaw, custom agents)
- Python 3.8+ only if you want to run the `tools/` utilities (optional)

## License

Commercial use allowed for the buyer. Redistribution or resale of the skill files themselves is not permitted.
