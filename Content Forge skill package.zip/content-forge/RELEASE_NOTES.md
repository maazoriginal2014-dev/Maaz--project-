# Release Notes

## v1.0.0 — Initial Release (2026-10-14)

First public release of Content Forge.

### Included
- `SKILL.md` with YAML frontmatter, identity, 3 operating modes, module router, hard rules, and standard build sequence
- Core brain: `core/voice-rules.md`, `core/decision-tree.md`, `core/output-standards.md`
- `pillars/pillar-builder.md` — 5-pillar funnel system (2 reach, 2 trust, 1 conversion)
- `calendar/30-day-calendar.md` — day-by-day engine with rotation rules and job labels
- `hooks/hook-formulas.md` — 8 hook formulas with examples and ranking method
- `scripts/short-form-script.md` — 15s/30s/60s structures with word budgets
- `scripts/long-form-script.md` — 8-minute YouTube retention structure
- `repurpose/repurposing-engine.md` — 1 piece → 10 outputs system
- `platform/` — native tactics for TikTok/Reels, YouTube, LinkedIn, X/Threads
- `templates/` — blank calendar CSV, script template, hook bank template
- `tools/check_environment.py` — Python version + capability check
- `tools/word_counter.py` — estimates spoken duration from word count
- `examples/sample-30-day-calendar.md` — fully worked example (fitness coach niche)
- `onboarding.md`, `setup.md`, `README.md`, `INSTALL_FOR_AGENTS.md`

### Design decisions
- File-based, zero API keys: works in any agent runtime, including offline
- Word budgets verified by tool, not guessed
- Every module ends with concrete output specs, not advice
