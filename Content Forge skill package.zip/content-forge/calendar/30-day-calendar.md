# 30-Day Calendar Engine

## Inputs

Pillars from `pillars/pillar-builder.md` + posts per week (default: 5).

## Rotation rules

1. **Never repeat a pillar two days in a row.** Alternate reach → trust → reach → trust → conversion across the week.
2. **Every 7th post is conversion.** With 5 posts/week, that's roughly 1 conversion post per week, 4-5 per month.
3. **Reach:trust ratio ≈ 40:40.** The remaining 20% is conversion.
4. **2 wildcard slots per month** marked WILD — reserved for jumping on trends. Never pre-fill them.
5. **Format rotation:** don't put the same format (e.g. talking head) more than twice in a row.

## Build procedure

**Step 1 — Lay out the days.** 30 rows: Day | Date | Pillar | Job | Format | Working title/hook | CTA.

**Step 2 — Assign pillars** following the rotation rules. Mark each row's job (R/T/C).

**Step 3 — Write working titles.** Every title must contain a curiosity gap, a number, or a bold claim. Bad: "Protein tips." Good: "37g protein, 4 minutes, 3 ingredients."

**Step 4 — Assign CTAs.** Reach posts → follow. Trust posts → comment a keyword or save. Conversion posts → link in bio / DM / book.

**Step 5 — Sanity check.** Count: ~12 reach, ~12 trust, ~4-5 conversion, 2 wild. No pillar back-to-back. No format 3x in a row.

## Output format

Markdown table. Then a summary block:

```text
Reach: 12 | Trust: 12 | Conversion: 4 | Wild: 2
Heaviest week: Week 3 (2 conversion posts — launch push)
Make these 3 first: Day 2 (reason), Day 5 (reason), Day 9 (reason)
```

## Weekly rhythm example (5 posts/week)

- Mon: Reach (Pillar 1) — broad hook, follow CTA
- Tue: Trust (Pillar 3) — expertise, save CTA
- Wed: Reach (Pillar 2) — contrarian take, follow CTA
- Thu: Trust (Pillar 4) — deep dive, comment CTA
- Fri: Conversion (Pillar 5) — proof/offer, link-in-bio CTA

Weekends: rest or repost winners. Reposting a winner with a new hook counts as a new post.
