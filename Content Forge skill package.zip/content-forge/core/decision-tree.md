# Decision Tree — Which Module to Use

Start here when the user's request doesn't name a module directly.

## By request type

- "Build me a content system / content strategy / posting plan"
  → Mode 1 full build: `onboarding.md` → `pillars/` → `calendar/` → `hooks/` → `scripts/`
- "What should I post about?" / "Give me content ideas"
  → `pillars/pillar-builder.md`, then pick 3 ideas to expand
- "Make me a calendar / 30-day plan"
  → `calendar/30-day-calendar.md` (needs pillars first — build them if missing)
- "Write hooks / I need better hooks"
  → `hooks/hook-formulas.md`
- "Write a Reel / TikTok script"
  → `scripts/short-form-script.md` + `platform/tiktok-reels.md`
- "Write a YouTube video script"
  → `scripts/long-form-script.md` + `platform/youtube.md`
- "Write a LinkedIn post"
  → `platform/linkedin.md` (hooks from `hooks/hook-formulas.md`)
- "Write a thread / X post"
  → `platform/x-threads.md`
- "Turn this into more content" / "Repurpose this"
  → `repurpose/repurposing-engine.md`
- "Review my content / why isn't this working"
  → Mode 3 audit: check against `core/output-standards.md`, then rebuild weak parts
- "Give me a blank template"
  → `templates/`

## By funnel stage

- Need reach (new audience) → pillars 1-2, hooks formulas 1-3, short-form scripts
- Need trust (warm audience) → pillars 3-4, long-form script, LinkedIn/X depth
- Need conversion (hot audience) → pillar 5, proof-led scripts, offer CTAs

## Escalation rule

If a request spans two modules (e.g. "hooks and scripts for my launch"), do them in dependency order: hooks first, then scripts — never in parallel, because the script needs the chosen hook.
