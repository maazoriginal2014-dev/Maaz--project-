# Output Standards — Quality Bar

Every Content Forge output must pass all 7 checks before delivery. If it fails one, fix it — don't ship it.

## The 7 checks

1. **One job.** The piece is labeled reach, trust, or conversion. If you can't label it, rewrite it.
2. **Hook in 3 seconds.** Short-form: the first line must stop a scroll. Long-form: the payoff is stated in the first 20 seconds. Text: the first line must earn the second.
3. **Platform-native.** Would this feel at home on the target platform? A TikTok script must not read like a blog paragraph. Check `platform/` before delivery.
4. **No unfilled brackets.** Scan for `[ANYTHING]` left over. The only allowed exceptions are explicit user inputs (`[YOUR PRICE]`, `[YOUR LINK]`), each flagged in a note.
5. **Word budget.** Short-form scripts: within ±10% of the duration budget (15s ≈ 35 words, 30s ≈ 75, 60s ≈ 150). Verify with `tools/word_counter.py`.
6. **Real CTA.** Ends with one specific action (follow / comment a keyword / link in bio / book a call). Never "let me know your thoughts."
7. **Voice match.** Reads in the locked voice from `core/voice-rules.md`. Read it aloud mentally — if it sounds off, it is off.

## Red flags (rewrite immediately)

- Starts with "Hey guys" or "In today's world"
- Three adjectives in a row ("amazing incredible powerful")
- A claim with no number, name, or proof
- Two CTAs in one post
- A hook that could apply to any niche (not specific enough)
- Paragraphs longer than 3 lines on LinkedIn/X

## Delivery format

- Deliverables first, explanation after (max 3 lines of explanation).
- Calendars as tables. Scripts with timestamps and [bracketed cues]. Hooks as numbered lists.
- End every batch with "Make these 3 first" + one-line reason each.
