# Voice Rules

Lock these before writing anything. The niche changes the words; the platform changes the rhythm.

## Universal rules (all platforms)

1. Write like a person talks, not like a brochure.
2. One idea per post. If a draft has two ideas, split it.
3. Specific beats generic: "37g protein in 4 minutes" beats "a healthy breakfast."
4. No hype words without proof: avoid "amazing," "incredible," "game-changer" unless a number follows.
5. Never start with "In today's fast-paced world." Never end with "What do you think? Comment below!" Write a real CTA instead.

## TikTok / Reels

- Spoken, punchy, under 150 words per 60s script.
- Sentence fragments are fine. Energy over grammar.
- On-screen text carries the keywords; the voice carries the personality.
- Example tone: "Nobody tells you this about protein. 37 grams. 4 minutes. Watch."

## YouTube

- Clear, paced, confident. Viewers stay for clarity, not hype.
- Front-load the payoff: say what they'll get in the first 20 seconds.
- Use "you" twice as often as "I."
- Example tone: "By the end of this video you'll have a meal plan that actually fits a 9-to-5 schedule."

## LinkedIn

- Professional, structured, skimmable. Short paragraphs, line breaks.
- Lead with the insight, then the story, then the lesson.
- No emojis in the first 3 lines (they collapse the preview).
- Example tone: "We cut client onboarding from 14 days to 3. Here's the exact change."

## X / Threads

- Compressed and witty. Every word earns its place.
- One strong opinion per post. Threads: one idea per tweet, escalate.
- Hooks under 15 words win.
- Example tone: "Your content isn't bad. Your first 3 seconds are."

## Voice lock procedure

After onboarding, write 3 sample sentences in the niche for the chosen platform and confirm the voice with the user before building pillars. If the user says "too formal" or "too casual," adjust once and lock it.
