# Sample 30-Day Calendar — Fictional Fitness Coach

**Niche:** Fitness coaching for busy moms 30-45
**Platform:** TikTok / Reels, 5 posts/week
**Pillars:** 1. Quick Wins (reach) · 2. Myth Busting (reach) · 3. Client Stories (trust) · 4. Deep Dives (trust) · 5. Program Proof (conversion)

| Day | Pillar | Job | Format | Working Title / Hook | CTA |
|---|---|---|---|---|---|
| 1 | Quick Wins | Reach | Talking head | 5-minute ab routine for moms with zero time | Follow |
| 2 | Client Stories | Trust | B-roll demo | Sara lost 8kg training 20 min/day — here's her week | Save |
| 3 | Myth Busting | Reach | Talking head | Cardio doesn't burn belly fat. This does. | Follow |
| 4 | Deep Dives | Trust | Carousel | Protein math: exactly how much you need (with chart) | Comment PROTEIN |
| 5 | Program Proof | Conversion | Talking head | Inside my 12-week Busy Mom program — week 1 tour | Link in bio |
| 6 | Quick Wins | Reach | B-roll demo | 3-ingredient breakfast, 37g protein, 4 minutes | Follow |
| 7 | Client Stories | Trust | Talking head | "I thought I needed the gym." Ayesha's home setup | Save |
| 8 | Myth Busting | Reach | Carousel | 5 "healthy" snacks that spike your blood sugar | Follow |
| 9 | Deep Dives | Trust | Talking head | Why sleep matters more than your workout split | Comment SLEEP |
| 10 | Program Proof | Conversion | B-roll demo | Client meal-prep Sunday: 5 meals, 40 minutes | Link in bio |
| 11 | Quick Wins | Reach | Talking head | Desk stretches that fix mom-posture in 3 minutes | Follow |
| 12 | Client Stories | Trust | Carousel | Before/after: Hira's 6-month strength journey | Save |
| 13 | Myth Busting | Reach | B-roll demo | Stop doing crunches. Do dead bugs instead. | Follow |
| 14 | WILD | Wild | Any | RESERVED FOR TREND | — |
| 15 | Deep Dives | Trust | Talking head | Progressive overload explained with grocery bags | Comment STRONG |
| 16 | Quick Wins | Reach | Carousel | 7 high-protein snacks under 200 calories | Follow |
| 17 | Program Proof | Conversion | Talking head | What you get in week 1 vs week 12 of the program | Link in bio |
| 18 | Client Stories | Trust | B-roll demo | Mahnoor trains at 6am before kids wake — her routine | Save |
| 19 | Myth Busting | Reach | Talking head | Eating MORE carbs is why my clients lose fat faster | Follow |
| 20 | Deep Dives | Trust | Talking head | The 80/20 of fat loss: kitchen, steps, sleep | Comment PLAN |
| 21 | Quick Wins | Reach | B-roll demo | 10-minute living-room circuit, no equipment | Follow |
| 22 | Program Proof | Conversion | Carousel | 12-week results wall: 9 transformations, 1 method | Link in bio |
| 23 | Client Stories | Trust | Talking head | "I failed 4 diets." What finally worked for Rabia | Save |
| 24 | Myth Busting | Reach | Talking head | Protein powder won't make you bulky — science says | Follow |
| 25 | Deep Dives | Trust | B-roll demo | How to read a nutrition label in 20 seconds | Comment LABEL |
| 26 | Quick Wins | Reach | Carousel | 5 freezer meals that reheat into 30g protein dinners | Follow |
| 27 | Client Stories | Trust | Talking head | From couch to 5k steps: Fatima's first 30 days | Save |
| 28 | WILD | Wild | Any | RESERVED FOR TREND | — |
| 29 | Program Proof | Conversion | Talking head | Enrollment opens Monday — here's who it's for (and not for) | Link in bio |
| 30 | Myth Busting | Reach | B-roll demo | The scale lied to you. Measure THIS instead. | Follow |

**Summary:** Reach 12 · Trust 12 · Conversion 4 · Wild 2
**Make these 3 first:** Day 13 (contrarian hook, proven format), Day 5 (program tour converts warm viewers), Day 19 (curiosity gap, high share potential).
