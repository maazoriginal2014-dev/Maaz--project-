# Hook Formulas — 8 Proven Openers

Write hooks in batches of 10-15. Rank them strongest → weakest with a one-line reason each.

## Formula 1 — The Contrarian
Pattern: "Stop [common advice]. Do [counter-move] instead."
Example: "Stop doing crunches. Do dead bugs instead — here's why."
Use for: reach. Works because disagreement stops scrolls.

## Formula 2 — The Curiosity Gap
Pattern: "The reason [pain] isn't working has nothing to do with [expected cause]."
Example: "The reason you're not losing weight has nothing to do with your diet."
Use for: reach. The gap between expectation and answer pulls viewers in.

## Formula 3 — The Numbered Promise
Pattern: "[Number] [things] that [desirable outcome] in [timeframe]."
Example: "3 breakfasts with 30g protein you can make in 5 minutes."
Use for: reach/trust. Specificity = credibility.

## Formula 4 — The Story Open
Pattern: "I [lost/gained/fixed] [thing] when I discovered [insight]."
Example: "I fixed my back pain when I stopped stretching my hamstrings."
Use for: trust. Stories earn the right to teach.

## Formula 5 — The Direct Callout
Pattern: "If you're [audience] struggling with [pain], [watch/read] this."
Example: "If you're a new mom who can't find 30 minutes to work out, watch this."
Use for: reach. The viewer self-identifies in 2 seconds.

## Formula 6 — The Mistake Reveal
Pattern: "[Number] mistakes [audience] make with [topic] — #[n] is the worst."
Example: "5 mistakes beginners make with protein powder — #3 wastes your money."
Use for: trust. Positions you as the corrector, not just another voice.

## Formula 7 — The Proof Drop
Pattern: "[Result] in [timeframe] — here's exactly how."
Example: "12kg down in 5 months — here's the exact weekly plan."
Use for: conversion. Proof first, method second.

## Formula 8 — The Question Flip
Pattern: "What if [common belief] is backwards?"
Example: "What if eating MORE carbs is why my clients lose fat faster?"
Use for: reach. Questions engage; flipped assumptions intrigue.

## Ranking method

After writing 10-15 hooks, rank them:
1. Specificity (names a number, a pain, or a timeframe?)
2. Scroll-stop power (would YOU stop for this?)
3. Payoff clarity (does the viewer know what they'll get?)

Top 3 get scripts first. The rest go in `templates/hook-bank-template.md` for later.
