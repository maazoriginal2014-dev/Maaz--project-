# Onboarding — First-Run Questions

Ask these on the first run of a new niche. Ask **maximum 3 questions**, then proceed. If the user already gave any of these, ask zero and use what you have.

## The 3 questions

1. **Niche** — "What niche is this content system for?" (e.g. fitness coaching, real estate, bakery)
2. **Audience** — "Who exactly is it for?" (e.g. busy moms 30-45, first-time home buyers in Lahore)
3. **Platform** — "Which platform first?" (TikTok/Reels, YouTube, LinkedIn, or X/Threads)

## Optional 4th (only if relevant)

4. **Offer** — "Is there something to sell at the end (service, product, course)?" This shapes the conversion pillar. If no offer, the conversion pillar becomes "proof/authority" content instead.

## After answers

1. Read `core/voice-rules.md` and lock the voice for this niche.
2. Run `pillars/pillar-builder.md`.
3. Follow the standard build sequence in `SKILL.md` section 5.

## Re-onboarding

If the user switches niche, audience, or platform mid-session: re-ask only what changed, rebuild pillars, and note that the old calendar no longer applies.
