# Pillar Builder — The 5-Pillar Funnel System

## The system

Every niche gets exactly 5 pillars covering the full funnel:

- **Pillars 1-2: REACH** — broad-appeal content that finds new people
- **Pillars 3-4: TRUST** — expertise content that converts viewers to followers
- **Pillar 5: CONVERSION** — proof and offer content that converts followers to customers

No pillar may serve two jobs. If an idea fits two pillars, assign it to the stronger one.

## Build procedure

**Inputs needed:** niche, audience, platform (from `onboarding.md`).

**Step 1 — Draft 8 candidate pillars.** For the niche, brainstorm 8 angles, each a 2-3 word name.

**Step 2 — Score each candidate** on:
- Reach potential (would a stranger stop for this?) 1-5
- Trust depth (does it prove expertise?) 1-5
- Content supply (can you make 20+ posts on this without repeating?) 1-5

**Step 3 — Pick 5** with the best combined coverage: 2 highest reach scores, 2 highest trust scores, 1 that naturally leads to the offer.

**Step 4 — Write up each pillar** with:
- Pillar name (2-3 words)
- Job: reach / trust / conversion
- What it covers and why the audience cares (2 lines)
- 5 seed topics under it
- Best format for this pillar (talking head / b-roll demo / carousel / thread / long video)

## Example (fitness coach, busy moms)

1. **Quick Wins** (reach) — 5-minute fixes anyone can try today. Topics: 5-min ab routine, desk stretches, 3-ingredient breakfasts...
2. **Myth Busting** (reach) — "cardio doesn't burn belly fat" style contrarian takes.
3. **Client Stories** (trust) — before/after narratives with the method explained.
4. **Deep Dives** (trust) — protein science, progressive overload explained simply.
5. **Program Proof** (conversion) — program walkthroughs, testimonials, offer posts.

## Rules

- Pillar names must be specific to the niche. "Tips" and "Motivation" are rejected — too generic.
- Every pillar needs 20+ posts of supply. If you can't list 5 seed topics easily, the pillar is too narrow — widen it.
- Revisit pillars every 90 days: drop the lowest-performing, promote the best sub-topic to a pillar.
