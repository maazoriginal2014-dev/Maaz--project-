# LinkedIn — Native Tactics

## What wins here

Dwell time + meaningful comments. LinkedIn rewards posts people read fully and discuss.

## Tactical rules

1. **The first 3 lines are everything.** They're all that shows before "see more." Make line 1 a hook, line 2 raise stakes, line 3 create the gap.
2. **Short paragraphs, lots of white space.** One idea per paragraph. Mobile readers skim — let them.
3. **No emojis in the first 3 lines.** They cheapen the preview. Use sparingly below.
4. **Insight → story → lesson.** The winning structure: open with the takeaway, tell the 3-line story behind it, close with what to do.
5. **End with a real question or CTA.** Not "thoughts?" — ask something answerable: "What's the one metric you check first on Mondays?"
6. **Post 3-5x weekly.** Quality compounds here; daily posting burns out and dilutes.
7. **Comment on 5 posts before you post.** 15 minutes of genuine commenting warms up your reach.

## Post skeleton

```text
[Hook — 1 line, bold claim or surprising number]

[2-3 lines of story/context]

[Line break]

[The lesson — what changed / what to do]

[Line break]

[CTA — question or next step]
```

## What to avoid

- Engagement bait ("comment YES if you agree")
- External links in the post body (kills reach — put links in comments)
- Corporate speak ("leverage synergies," "thrilled to announce")
- Posting company news nobody asked for
