# TikTok / Reels — Native Tactics

## What wins here

Watch time + replays + shares. The algorithm rewards videos people finish and send to friends.

## Tactical rules

1. **First frame = the hook.** The viewer decides in under 1 second. Start mid-action or with bold on-screen text — never a logo or a greeting.
2. **Loop it.** End the video so it flows back into the start (repeat the hook phrase, return to the opening visual). Loops inflate watch time.
3. **Text on screen always.** 80%+ watch muted at first. On-screen text must carry the full message alone.
4. **One idea per video.** Two ideas = the viewer picks neither. Split them.
5. **Post 1-2x daily** while growing. Consistency beats production value here.
6. **Reply to comments with video.** Every good comment is a free content idea with a built-in audience.
7. **Trending sounds:** use them only when they fit the niche. A forced trend confuses the algorithm about your audience.
8. **Length sweet spot:** 21-34 seconds for reach; 60s+ for depth once you have followers.

## Caption formula

Hook line (repeat the video's promise) + 1 line of context + CTA. Hashtags: 3-5, niche-specific, never #fyp alone.

## What to avoid

- Watermarks from other apps (kills reach)
- Stock footage montages with no face or voice
- Posting and ghosting — spend 15 min engaging after each post
- Deleting underperforming videos (the algorithm sometimes finds them late)
