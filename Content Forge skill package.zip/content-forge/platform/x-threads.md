# X / Threads — Native Tactics

## What wins here

Reposts + profile clicks. X rewards strong opinions people want to attach their name to.

## Tactical rules

1. **One opinion per post.** Threads: one idea per tweet, escalating. Never two arguments in one thread.
2. **Hooks under 15 words.** "Your content isn't bad. Your first 3 seconds are." Long setups die.
3. **Write in the open.** Share the process, the numbers, the mistakes — in public, in real time. "Building in public" still works when it's honest.
4. **Reply more than you post.** 60% replies, 40% posts. Replies are where new audiences discover you.
5. **Threads structure:** tweet 1 = hook, tweets 2-7 = one point each with proof, last tweet = CTA + "follow for more on [niche]."
6. **Post 1-3x daily.** The feed moves fast; volume + quality wins.
7. **Pin your best thread.** Your pinned post is your landing page — make it the one that converts visitors to followers.

## Formats that work

- **The list:** "7 tools I use daily as a [role]:" — simple, saveable
- **The teardown:** "I analyzed [person]'s [thing]. Here's what I found:" — borrows authority
- **The confession:** "I was wrong about [topic]. Here's what changed my mind:" — disarming, high trust
- **The framework:** "My [process] in 5 steps:" — positions expertise

## What to avoid

- Hashtags (dead on X, noise on Threads)
- Link-dropping without context
- Ratio-bait controversy with no substance behind it
- Scheduling everything and never being present
