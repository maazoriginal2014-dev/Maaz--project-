# YouTube — Native Tactics

## What wins here

Click-through rate + average view duration. YouTube promotes videos people choose and finish.

## Tactical rules

1. **Title + thumbnail = 80% of the battle.** Write 5 titles per video, pick the most specific. Thumbnail: 3 words max, one expressive visual, high contrast.
2. **The first 30 seconds decide everything.** State the payoff, show the roadmap, start the content. No animated intros.
3. **Pattern interrupts every 60-90s.** Camera angle change, b-roll, on-screen graphic, story, question. Stillness = click-away.
4. **Chapters help retention.** Timestamped chapters let skimmers jump — and jumping beats leaving.
5. **End screens earn the next view.** Bridge verbally: "This video solved X — next, watch [title] for Y."
6. **Post 1-2x weekly.** YouTube rewards consistency over volume. One great video beats five mediocre ones.
7. **Shorts as feeders.** Post Shorts that tease the long video's best 20 seconds, with a pinned comment linking it.

## Title formulas that work

- Number + outcome + timeframe: "I Tested 5 Protein Powders for 30 Days"
- Mistake + audience: "5 Camera Settings Beginners Always Get Wrong"
- Transformation + proof: "0 to 10k Subscribers: The Exact 90-Day Plan"

## What to avoid

- Clickbait the video can't pay off (destroys trust + retention)
- Asking for subs in the first 3 minutes
- 10-minute videos with 3 minutes of content
- Ignoring comments in the first 24 hours (early engagement signals matter)
