# Repurposing Engine — 1 Piece → 10 Outputs

## Principle

One strong idea, ten native formats. Each output must feel made for its platform — never a chopped-up copy.

## Input

One long-form piece: video transcript, blog post, newsletter, or detailed notes (minimum 300 words of substance).

## The 10 outputs

1. **3 short-form scripts** — same core idea, 3 different hooks (use `hooks/hook-formulas.md`, pick 3 different formulas). 30s each.
2. **1 carousel** — 7-10 slides: slide 1 = hook, slides 2-8 = one point each, last slide = CTA. (Instagram/LinkedIn)
3. **1 X thread** — 6-10 tweets: tweet 1 = hook, each tweet one idea, last tweet = CTA. Punchy, no fluff.
4. **1 LinkedIn post** — insight → short story → lesson → CTA. Professional voice, line breaks.
5. **5 one-liners** — the strongest standalone lines, each under 20 words, ready as single posts.
6. **1 newsletter section** — subject line + 150 words expanding the idea with a personal angle.
7. **1 YouTube community/shorts idea** — poll question or 15s teaser pointing to the full piece.
8. **1 FAQ/answer post** — frame the idea as an answer to a common question ("How do I...?").
9. **1 myth-bust post** — take the most contrarian angle of the piece, lead with it.
10. **1 behind-the-scenes post** — how you learned this / what almost went wrong making it.

## Procedure

1. Read the source piece. Extract: core idea (1 line), 3 strongest points, 1 best story, 1 most contrarian angle.
2. Generate outputs 1-10 in order. Short-form scripts first (highest leverage).
3. For each output, note which pillar and job (reach/trust/conversion) it serves.
4. Flag any output that feels forced — cut it and note why. 8 strong beats 10 weak.

## Scheduling tip

Drip the 10 outputs over 2-3 weeks, not 2 days. Same idea, spaced out, reaches different slices of the audience each time.
