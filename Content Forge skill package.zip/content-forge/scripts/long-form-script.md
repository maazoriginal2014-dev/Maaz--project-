# Long-Form Script Writer (YouTube ~8 minutes)

Target: ~1,000-1,200 words for 8 minutes at natural pace.

## Retention structure

**0:00-0:20 — Cold open.** State the payoff, not the topic. "By the end of this video you'll have a full week of high-protein meals that take under 15 minutes." No channel intro, no "welcome back."

**0:20-1:00 — Stakes.** Why this matters now, in the viewer's words. One relatable pain scene. Then the roadmap: "Three parts — the mistake, the method, the plan."

**1:00-3:00 — Part 1: The mistake.** What most people do wrong and why it fails. Be specific and fair — strawmen kill trust.

**3:00-5:30 — Part 2: The method.** The core teaching. 3 steps max. Each step: what → why → how. Use pattern interrupts every 60-90 seconds: a story, a number on screen, a rhetorical question.

**5:30-7:00 — Part 3: The plan.** Make it actionable this week. A checklist, a template, or a worked example. This is the most-saved section — make it dense.

**7:00-7:30 — Recap.** 3 bullets, 10 seconds each. Rewards completers and serves skimmers.

**7:30-8:00 — CTA + bridge.** One CTA (subscribe / next video). Bridge to the next video: "Next, watch [title] — it covers [specific gap this video left]."

## Rules

- Open loops: tease part 3 during part 1 ("and at the end I'll give you the exact template").
- Every 90 seconds, answer the viewer's silent question: "why should I keep watching?"
- B-roll / graphic cues in [brackets], chapter markers as ## headers.
- No "smash that like button" in the first 3 minutes. Earn it first.
- Title and thumbnail concept delivered with the script: title under 60 chars, thumbnail = 3 words max + expressive visual.
