# Short-Form Script Writer (15s / 30s / 60s)

## Word budgets (verify with tools/word_counter.py)

| Duration | Words | Beats |
|---|---|---|
| 15s | ~35 (±4) | Hook + 1 beat + CTA |
| 30s | ~75 (±8) | Hook + 2 beats + CTA |
| 60s | ~150 (±15) | Hook + 3 beats + CTA |

One beat = one idea. Never 4 beats in 60 seconds — depth beats breadth.

## Structure

**0-3s — HOOK.** Say the hook line verbatim. On-screen text = the hook's keywords. No intro, no name, no "hey guys."

**Setup (next 20%).** Agitate the pain in one line. "You've been doing X for months and Y still hasn't changed."

**Payoff (middle 60%).** The beats. Each beat: claim → 1-line proof or demo. B-roll or text cue per beat in [brackets].

**CTA (last 5s).** One action: follow / comment [KEYWORD] / link in bio. Say the keyword slowly and put it on screen.

## Worked example (30s, fitness niche)

```text
[0-3s] "Stop doing crunches. They don't burn belly fat."
[on-screen: "crunches DON'T burn fat"]

[3-8s] "You've done hundreds and the belly's still there. Here's what actually works."

[8-22s] "Fat loss is 80% kitchen. One: protein at every meal — 30 grams minimum.
[on-screen: "30g protein/meal"]
Two: walk 8,000 steps daily. Boring, but it works.
[b-roll: walking footage]
Three: sleep 7 hours. Bad sleep spikes hunger hormones."

[22-30s] "Follow for the 5-minute ab routine that actually builds muscle.
[on-screen: "FOLLOW for ab routine"]"
```

Word count: 74. In budget.

## Rules

- Write the script exactly as spoken — contractions, fragments, spoken rhythm.
- [Bracketed cues] for b-roll, on-screen text, and sound changes only.
- Read it aloud mentally at natural pace. If a line feels long, cut it.
- The CTA keyword must be one memorable word, spelled on screen.
- After writing, run `python3 tools/word_counter.py --words <count>` to confirm the duration fits.
