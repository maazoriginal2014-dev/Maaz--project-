# Setup — Folder Map + Read Order

## Folder map

```text
content-forge/
├── SKILL.md                  Agent entry point: identity, modes, router, hard rules
├── README.md                 Human overview
├── INSTALL_FOR_AGENTS.md     Per-runtime install steps
├── RELEASE_NOTES.md          Version history
├── _meta.json                Package metadata
├── MANIFEST.json             Exact file list
├── onboarding.md             First-run questions (niche, audience, platform)
├── setup.md                  This file
├── core/
│   ├── voice-rules.md        Brand voice rules per platform
│   ├── decision-tree.md      Which module to use for which request
│   └── output-standards.md   Quality bar every output must pass
├── pillars/
│   └── pillar-builder.md     5-pillar funnel system
├── calendar/
│   └── 30-day-calendar.md    Day-by-day engine + rotation rules
├── hooks/
│   └── hook-formulas.md      8 hook formulas with examples
├── scripts/
│   ├── short-form-script.md  15s / 30s / 60s structures + word budgets
│   └── long-form-script.md   8-minute YouTube retention structure
├── repurpose/
│   └── repurposing-engine.md 1 piece → 10 outputs
├── platform/
│   ├── tiktok-reels.md       TikTok / Reels native tactics
│   ├── youtube.md            YouTube native tactics
│   ├── linkedin.md           LinkedIn native tactics
│   └── x-threads.md          X / Threads native tactics
├── templates/
│   ├── content-calendar-template.csv  Blank 30-day calendar
│   ├── script-template.md    Blank short-form script
│   └── hook-bank-template.md Blank hook bank
├── tools/
│   ├── check_environment.py  Python version + capability check
│   └── word_counter.py       Spoken-duration estimator
└── examples/
    └── sample-30-day-calendar.md  Worked example (fitness coach)
```

## Read order for agents

1. `SKILL.md` — always first
2. `onboarding.md` — on first run of a new niche
3. `core/voice-rules.md` → `core/decision-tree.md` → `core/output-standards.md`
4. The module matching the task (see router in SKILL.md)
5. The matching `platform/` file before writing any post
6. `templates/` when the user wants blanks to fill themselves
7. `examples/` when the user wants to see a finished result

## Read order for humans

`README.md` → `onboarding.md` → `examples/sample-30-day-calendar.md` → any module.
