# Hook Bank Template

Fill one row per hook. Rank quarterly: promote the top 3 to scripts, retire the bottom 3.

| # | Hook text | Formula | Pillar | Job | Used? | Result |
|---|---|---|---|---|---|---|
| 1 | | Contrarian | | Reach | No | |
| 2 | | Curiosity gap | | Reach | No | |
| 3 | | Numbered promise | | Reach | No | |
| 4 | | Story open | | Trust | No | |
| 5 | | Direct callout | | Reach | No | |
| 6 | | Mistake reveal | | Trust | No | |
| 7 | | Proof drop | | Conversion | No | |
| 8 | | Question flip | | Reach | No | |
| 9 | | | | | No | |
| 10 | | | | | No | |
| 11 | | | | | No | |
| 12 | | | | | No | |
| 13 | | | | | No | |
| 14 | | | | | No | |
| 15 | | | | | No | |

**Ranking rules:** specificity first (number/pain/timeframe?), then scroll-stop power, then payoff clarity.
**Retirement rule:** any hook unused after 60 days gets rewritten or deleted.
