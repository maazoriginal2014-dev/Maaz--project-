# Script Template — Short-Form

**Niche:**
**Platform:** TikTok / Reels
**Duration:** 15s / 30s / 60s
**Word budget:** ___ words (15s≈35, 30s≈75, 60s≈150)
**Pillar / Job:** ___ / Reach / Trust / Conversion

---

**[0-3s] HOOK:**
_Say it verbatim. On-screen text:_

**[Setup]:**
_Agitate the pain in one line._

**[Beat 1]:**
_Claim + 1-line proof. B-roll/text cue:_

**[Beat 2]:**
_(30s/60s only)_

**[Beat 3]:**
_(60s only)_

**[CTA — last 5s]:**
_One action. Keyword on screen:_

---

**Word count:** ___
**Checked with tools/word_counter.py:** yes / no
