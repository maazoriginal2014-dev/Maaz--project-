#!/usr/bin/env python3
"""Content Forge — environment check.

Verifies the Python runtime meets the skill's tool requirements.
No third-party packages needed.
"""

import sys


def main() -> int:
    print("Content Forge — environment check")
    print(f"Python version: {sys.version.split()[0]}")

    ok = True

    if sys.version_info < (3, 8):
        print("FAIL: Python 3.8+ is required.")
        ok = False
    else:
        print("OK: Python 3.8+ present.")

    # word_counter.py is the only companion tool; confirm it exists beside this file.
    from pathlib import Path

    here = Path(__file__).resolve().parent
    wc = here / "word_counter.py"
    if wc.exists():
        print("OK: tools/word_counter.py found.")
    else:
        print("FAIL: tools/word_counter.py missing.")
        ok = False

    if ok:
        print("Environment ready.")
        return 0
    print("Environment NOT ready — see failures above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
