#!/usr/bin/env python3
"""Content Forge — spoken-duration estimator.

Estimates how long a script takes to speak from its word count.
Average English speaking rate: ~150 words per minute (2.5 words/sec).

Usage:
    python3 word_counter.py --words 150
    python3 word_counter.py --text "your script text here"
    python3 word_counter.py --file script.txt
"""

import argparse
import sys
from pathlib import Path

WPM = 150  # average speaking rate

TARGETS = {
    "15s": (31, 39),
    "30s": (67, 83),
    "60s": (135, 165),
}


def estimate(words: int) -> dict:
    seconds = words / WPM * 60
    fit = []
    for label, (lo, hi) in TARGETS.items():
        if lo <= words <= hi:
            fit.append(label)
    return {"words": words, "seconds": round(seconds, 1), "fits": fit}


def main() -> int:
    parser = argparse.ArgumentParser(description="Estimate spoken duration from word count.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--words", type=int, help="Word count, e.g. --words 150")
    group.add_argument("--text", help="Script text in quotes")
    group.add_argument("--file", help="Path to a text file containing the script")
    args = parser.parse_args()

    if args.words is not None:
        words = args.words
    elif args.text is not None:
        words = len(args.text.split())
    else:
        words = len(Path(args.file).read_text(encoding="utf-8").split())

    result = estimate(words)
    print(f"Words: {result['words']}")
    print(f"Estimated spoken duration: ~{result['seconds']}s")

    if result["fits"]:
        print(f"Fits target: {', '.join(result['fits'])}")
    else:
        print("Does not fit 15s/30s/60s budgets — trim or expand the script.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
