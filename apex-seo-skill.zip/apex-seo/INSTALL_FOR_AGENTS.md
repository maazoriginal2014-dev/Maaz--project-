# Install Apex SEO in AI Agents

Apex SEO needs no API keys and no paid services. The skill works from data the user provides (site URL, sitemap, pasted content) plus the three bundled Python tools.

## Codex

1. Keep the folder name as `apex-seo`.
2. Make sure `SKILL.md` is at the folder root (it carries YAML frontmatter for skill discovery).
3. Add the folder to the project or skills directory.
4. Tell Codex: "Use the Apex SEO skill. Read SKILL.md first."

## Claude Projects

1. Upload the `apex-seo` folder (or `apex-seo-skill.zip`).
2. Add this project instruction:

```text
Use the Apex SEO skill as the operating system for SEO audits, keyword research,
local SEO, strategy, and reporting. Read SKILL.md first, then follow its router.
```

## Cursor / Local Agents

1. Place the `apex-seo` folder inside the repo or agent workspace.
2. Open `SKILL.md` and follow the router to the right playbook.
3. Run the Python tools directly when needed:

```bash
python3 apex-seo/tools/check_environment.py
python3 apex-seo/tools/sitemap_extractor.py https://example.com
python3 apex-seo/tools/url_classifier.py urls.txt
```

## Custom File-Based Agents

1. Mount or copy the folder where the agent can read Markdown and run Python.
2. Register the skill name as `apex-seo` with entry point `SKILL.md`.
3. The agent should read, in order: `SKILL.md` → `setup.md` → `onboarding.md` → the routed playbook.

## Python tools

Standard library only — no `pip install` needed. Requires Python 3.8+.

```bash
python3 tools/check_environment.py   # verifies the runtime
```

## Notes

- No tokens, keys, or credentials are required or stored anywhere in this skill.
- Reports and templates are plain Markdown/CSV — safe to version-control.
- Keep the folder structure intact; playbooks reference each other by relative path.
