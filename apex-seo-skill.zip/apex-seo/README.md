# Apex SEO

**Version 1.0.0 — by Maaz Iqbal**

Apex SEO is a portable AI-agent skill that turns any compatible AI agent into a working SEO consultant. It ships as a folder of playbooks, templates, and small Python tools — no paid APIs, no subscriptions, no tokens required.

## What it does

- **Audits** — technical SEO, on-page SEO, and content quality audits with business-impact prioritization.
- **Keyword research** — discovery from seed topics and competitor pages, search intent analysis, clustering, and keyword-to-page mapping.
- **Local SEO** — Google Business Profile optimization and local keyword targeting.
- **Strategy** — content hub (pillar + cluster) architecture and 30-60-90 day execution plans.
- **Reporting** — client-ready audit reports and one-page executive summaries, from templates.
- **Tools** — sitemap URL extractor, URL classifier, and environment checker (plain Python, standard library only).

## Install summary

1. Place the `apex-seo` folder where your agent can read files (project folder, skills directory, or Claude Project knowledge).
2. Tell the agent: "Use the Apex SEO skill. Read SKILL.md first."
3. Optional: run `python3 tools/check_environment.py` to confirm Python works for the tools.

Full per-agent steps: see `INSTALL_FOR_AGENTS.md`.

## How the agent uses it

`SKILL.md` is the entry point — it contains the identity, the runtime rules, and a router table pointing to every playbook. The agent reads `onboarding.md` for first-run questions, picks playbooks via `core/decision-tree.md`, and formats everything per `core/output-standards.md`.

## Version history

- **v1.0.0** — Initial release. Full audit engine (4 playbooks), keyword research engine (4 playbooks), local SEO module (2 playbooks), strategy module (2 playbooks), reporting module (2 playbooks), 4 templates, 3 Python tools, 1 worked example, install docs for Codex / Claude Projects / Cursor / custom agents.
