# Release Notes — Apex SEO

## v1.0.0 — Initial release

First public release of the Apex SEO agent skill.

**Included:**
- `SKILL.md` with YAML frontmatter, agent identity, playbook router, and hard data-quality rules.
- Core brain: SEO principles, decision tree, and output standards (`core/`).
- Audit engine: technical audit, on-page audit, content quality audit, issue prioritization (`audit/`).
- Keyword research engine: discovery, search intent, clustering, keyword-to-page mapping (`keyword-research/`).
- Local SEO module: Google Business Profile optimization, local keyword targeting (`local-seo/`).
- Strategy module: 30-60-90 day plan builder, content hub strategy (`strategy/`).
- Reporting module: client audit report builder, executive summary builder (`reporting/`).
- Templates: keyword map CSV, issue log CSV, page brief, full audit report (`templates/`).
- Tools: sitemap extractor, URL classifier, environment checker — standard-library Python, no installs (`tools/`).
- Worked example: a filled-in sample audit for a fictional bakery site (`examples/`).
- Install docs for Codex, Claude Projects, Cursor, and custom agents.

**Design decisions:**
- No paid APIs required. The skill works from user-provided data, sitemaps, and pasted content.
- Every playbook is standalone: the agent reads only what the router points to.
- Data honesty is enforced in SKILL.md: no invented metrics, estimates labeled, no outcome guarantees.
