# Content Quality Audit

**Purpose:** Find thin, duplicate, outdated, or low-value content that drags the site down.
**Inputs:** URL list (from sitemap extractor) or pasted content samples + niche context.
**Outputs:** Content action table: Keep / Improve / Merge / Delete per URL group.

## Steps

### 1. Inventory
- Use the classified URL list from `tools/url_classifier.py`.
- Group by section (blog, product, category). Note publish dates if visible.

### 2. Thin content scan
Flag pages that are likely thin:
- Under ~400 words with no images, video, or data (blog posts).
- Product/category pages with only a title and a sentence.
- Tag, archive, or auto-generated pages with near-zero unique text.
- For each: is the topic worth expanding, or should the page go?

### 3. Duplicate and overlap scan
- URLs with near-identical titles or slugs.
- Multiple posts covering the same keyword (check against `keyword-research/keyword-to-page-map.md` if it exists).
- Boilerplate repeated across many pages (same intro paragraph everywhere).
- Decision: keep the strongest, merge the rest with 301 redirects (note: redirects need developer implementation — your job is to specify which URL survives).

### 4. Freshness scan
- Posts older than 18-24 months in fast-moving niches (tech, health, finance, marketing).
- Statistics, prices, screenshots, or "best of [old year]" references.
- Seasonal content that missed its season.
- Decision: update (with what new info) or retire.

### 5. Intent mismatch scan
- Pages ranking (or trying to rank) for keywords whose intent they don't serve — e.g., a product page targeting a "how to" query.
- Use `keyword-research/search-intent.md` to classify, then recommend: rewrite to match intent, or retarget to a different keyword.

### 6. E-E-A-T signals (qualitative)
- Is there an author name and bio on articles?
- Any original data, photos, case results, or first-hand experience?
- About page, contact page, and privacy policy present?
- Note gaps — these build trust with both users and search engines.

## Output
Table: URL or URL group | Issue type (Thin / Duplicate / Outdated / Mismatch) | Recommended action (Keep / Improve / Merge / Delete) | Notes on what "Improve" means specifically. Then feed into `audit/issue-prioritization.md`.
