# Issue Prioritization

**Purpose:** Turn raw audit findings into an ordered action list by business impact.
**Inputs:** Issue tables from any of the audit playbooks.
**Outputs:** Single ranked list: fix this first → fix this last.

## Scoring method

Score each issue on two axes, 1-3 each:

**Impact** (what happens if fixed):
- 3 = directly affects indexation, rankings of money pages, or conversions.
- 2 = affects a meaningful set of pages or a secondary ranking factor.
- 1 = minor improvement, mostly hygiene.

**Effort** (what it costs to fix):
- 1 = quick win — minutes to a day, no developer needed (titles, meta, alt text, GBP fields).
- 2 = project — days to a week, needs a developer or writer.
- 3 = initiative — weeks, structural changes (migration, redesign, large content program).

**Priority score = Impact × (4 − Effort).** Higher is better. A Critical-impact quick win scores 9; a low-impact initiative scores 1.

## Ordering rules

1. Sort by priority score, highest first.
2. Ties: Critical severity before High before Medium before Low.
3. Never bury a Critical issue below a Medium one, even on ties — bump Criticals up.
4. Group the final list into: **This week** (score 7-9), **This month** (score 4-6), **This quarter** (score 1-3).

## Output format

Table: # | Issue | Location | Severity | Impact | Effort | Score | Timeframe.

Follow with a short paragraph: "If you only do three things, do these:" — the top 3, each with the expected outcome in plain language (e.g., "Fixing the missing H1s on 12 product pages should help them match search intent better — estimate, not a guarantee").

## Notes
- Re-score after major fixes; priorities change as the site improves.
- Keep the scored list — `strategy/30-60-90-day-plan.md` consumes it directly.
