# On-Page SEO Audit

**Purpose:** Evaluate the ranking elements of individual pages: titles, headings, meta, content structure, links, and images.
**Inputs:** Page URL(s) or pasted page content + the primary keyword each page targets.
**Outputs:** Per-page scorecard plus fix list.

## Steps

### 1. Title tag
- Present and under 60 characters? Primary keyword near the front?
- Unique across the site (no duplicates)?
- Compelling for clicks (benefit, number, or curiosity — not just keywords)?
- Fix: rewrite weak titles on the spot, showing before → after.

### 2. Meta description
- Present, 150-155 characters, includes keyword naturally?
- Written as ad copy (reason to click), not a keyword dump?
- Fix: rewrite weak ones with a clear value proposition + soft CTA.

### 3. Heading structure
- Exactly one H1 containing the primary keyword or close variant?
- H2s cover the topic's subtopics in logical order?
- No skipped levels (H1 → H3), no keyword-stuffed headings?
- Fix: propose a restructured H1/H2 outline.

### 4. Content-to-keyword fit
- Primary keyword in the first 100 words?
- Natural variations and related terms present (not forced)?
- Content actually matches the intent from `keyword-research/search-intent.md`?
- Fix: list specific insertions (where, what wording) — never "add more keywords."

### 5. Internal links
- Does the page link out to 3+ relevant internal pages with descriptive anchor text?
- Do relevant pages link back to it?
- Any "click here" / "read more" anchors? Replace with descriptive ones.
- Fix: propose exact anchor text and target URLs.

### 6. Images
- Descriptive file names and alt text (not "IMG_001")?
- Alt text describes the image for accessibility first, keyword second?
- Oversized images flagged for compression?

### 7. URL slug
- Short, readable, contains the primary keyword?
- No dates, IDs, or stop-word stuffing?

### 8. Schema opportunities
- Could this page carry FAQ, HowTo, Product, Review, or LocalBusiness schema? Note which type fits — implementation is the developer's job, flagging it is yours.

## Scoring
Rate each page: Strong / Needs work / Weak — with the top 3 fixes listed. A page is "Strong" only if it passes all 8 checks.

## Output
One scorecard per page, then a combined fix list. If multiple pages target the same keyword, flag cannibalization and point to `keyword-research/keyword-to-page-map.md`.
