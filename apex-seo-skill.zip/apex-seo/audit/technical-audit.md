# Technical SEO Audit

**Purpose:** Find crawlability, indexation, and site-health issues.
**Inputs:** Domain (for sitemap extraction), or a pasted URL list, or uploaded crawl data.
**Outputs:** Issue table per `core/output-standards.md`.

## Steps

### 1. Map the site
- Run `tools/sitemap_extractor.py` on the domain's sitemap (try `/sitemap.xml`, then `/sitemap_index.xml`).
- Run `tools/url_classifier.py` on the extracted URLs to see the site's structure (blog / product / category / other).
- Note: total URL count, depth of nesting, any URL patterns that look like duplicates (parameters, trailing slashes, www vs non-www).

### 2. Indexation check
- Ask the user: "Is the site indexed? Check by searching Google for `site:yourdomain.com` — roughly how many results show?"
- Compare indexed count vs sitemap count. Large gaps mean crawl or quality problems.
- Flag: important pages missing from the sitemap; junk pages (tags, thin archives) included in the sitemap.

### 3. Crawlability check
- HTTPS: is the whole site on HTTPS with no mixed content?
- Redirects: www vs non-www resolved to one version? HTTP redirects to HTTPS?
- Robots.txt: fetch `/robots.txt` — anything blocking important paths?
- URL hygiene: excessively long URLs, session IDs, or duplicate paths?

### 4. Site structure check
- Click depth: are money pages reachable within 3 clicks from the homepage?
- Orphan risk: pages in the sitemap with no clear parent section (from the classifier output).
- Internal linking: does the homepage link to key category/product pages with descriptive anchors?

### 5. Page experience signals (observable, no paid tools)
- Ask the user to run Google PageSpeed Insights on 3 key pages and paste the scores, or note obvious issues (huge images, layout shift, slow loads on mobile).
- Mobile: is the layout usable on a phone? (ask the user or check via their description)
- Intrusive interstitials: popups blocking content on mobile?

### 6. Record issues
Log every finding in the issue format from `core/output-standards.md`. Severity guide:
- **Critical:** site not indexed, HTTPS broken, robots blocking everything, redirect loops.
- **High:** large indexation gaps, money pages 4+ clicks deep, no sitemap.
- **Medium:** duplicate URL patterns, weak internal linking, slow key pages.
- **Low:** minor URL hygiene, missing image compression on non-key pages.

## Output
A markdown section titled "Technical Audit" with the issue table, then hand off to `audit/issue-prioritization.md` if other audits are also running.
