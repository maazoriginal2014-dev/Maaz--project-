# Decision Tree — Which Playbook To Use

Start here when the user's request could match more than one playbook. Read the matching playbook file(s) in the order listed.

## "Audit my site" / "What's wrong with my SEO?"
1. `audit/technical-audit.md` — crawlability and health first.
2. `audit/on-page-audit.md` — titles, headings, meta, links, images.
3. `audit/content-quality-audit.md` — thin, duplicate, outdated content.
4. `audit/issue-prioritization.md` — rank everything found by impact.
5. `reporting/client-audit-report.md` — assemble the client document.

## "My pages aren't ranking"
1. `audit/on-page-audit.md` — check the struggling pages.
2. `keyword-research/search-intent.md` — verify intent match.
3. `audit/content-quality-audit.md` — check depth vs competitors.
4. `keyword-research/keyword-to-page-map.md` — check for cannibalization.

## "Find me keywords" / "Keyword research"
1. `keyword-research/keyword-discovery.md` — build the raw list.
2. `keyword-research/search-intent.md` — classify each keyword.
3. `keyword-research/keyword-clustering.md` — group into topics.
4. `keyword-research/keyword-to-page-map.md` — assign to pages.

## "Plan my content" / "Content strategy"
1. `keyword-research/keyword-clustering.md` — topic groups first.
2. `strategy/content-hub-strategy.md` — pillar + cluster architecture.
3. `strategy/30-60-90-day-plan.md` — phased execution.

## "Local SEO" / "Rank in my city"
1. `local-seo/google-business-profile.md` — profile optimization.
2. `local-seo/local-keywords.md` — city/modifier keyword targeting.
3. `audit/on-page-audit.md` — location signals on the site itself.

## "Give me an SEO plan" / "Roadmap"
1. `audit/issue-prioritization.md` — if an audit exists, start from it.
2. `strategy/30-60-90-day-plan.md` — build the phased plan.

## "Write me a report" / "Client report"
1. `reporting/client-audit-report.md` — full report.
2. `reporting/executive-summary.md` — one-page version for owners.

## "Optimize this page" (single URL or pasted content)
1. `audit/on-page-audit.md` — element-by-element pass.
2. `keyword-research/search-intent.md` — confirm the page matches intent.

## Quick rules
- Technical issues always come before content work (principle 1).
- Never skip `audit/issue-prioritization.md` after running more than one audit playbook.
- If the user only wants one thing, run only that playbook — don't upsell the full suite.
- When in doubt between two playbooks, read both headers (first 15 lines) and pick.
