# Output Standards

Every deliverable from this skill follows these formatting rules.

## General format
- Markdown only. No PDFs, no proprietary formats.
- Start with a one-line summary of what the deliverable is.
- Use headers, tables, and bullet lists — never walls of text.
- End every deliverable with a **Next step** section: the single most important action.

## Tables
- Use tables for any list longer than 5 items with multiple attributes (issues, keywords, pages).
- Columns must have clear headers. Keep cell text short.

## Issue reporting
Each issue gets: what it is (one line), where it was found (URL or "site-wide"), why it matters (business impact, one line), severity (Critical / High / Medium / Low), and effort (Quick win / Project).

## Keyword reporting
Each keyword gets: keyword, intent (Learn / Compare / Buy), difficulty tier (Easy / Medium / Hard — labeled as estimate unless measured), suggested page type, and cluster name.

## Estimates
- Any number you did not measure is followed by "(estimate)".
- Never present estimates in charts or tables without the label.

## Tone
- For business owners: plain language, brief explanation of each SEO term on first use.
- For marketers/teams: direct and technical, skip the explanations.
- Never hype. "This should help" beats "this will skyrocket."

## Length
- Executive outputs: fit on one page.
- Audit reports: as long as needed, but every section earns its place.
- No filler intros, no generic SEO advice the user didn't ask for.

## File outputs
- When producing a file (CSV, report), name it clearly: `keyword-map-<site>-<date>.csv`.
- CSVs use UTF-8, comma-separated, with a header row matching the templates in `templates/`.
