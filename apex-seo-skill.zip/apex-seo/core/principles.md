# Core SEO Principles

Every playbook in this skill follows these principles. When two recommendations conflict, the higher principle wins.

## 1. Crawlability before everything
If search engines cannot reach, render, and understand a page, nothing else matters. Technical health (indexation, crawl budget, site structure, page experience) is always fixed before content expansion.

## 2. Intent match beats keyword match
A page ranks when it gives the searcher what they actually wanted — not when it repeats a keyword the most times. Every page targets one clear intent: learn, compare, or buy.

## 3. One page, one job
Each URL owns one primary keyword and one intent. Two pages chasing the same keyword cannibalize each other. When overlap exists, merge or differentiate.

## 4. Depth earns authority
Thin pages rarely rank for competitive terms. A page should answer its topic more completely than the current top results — more useful subtopics, clearer structure, fresher information.

## 5. Structure is a ranking factor in practice
Clear heading hierarchy, descriptive internal anchor text, and logical URL paths help both crawlers and users. A messy site leaks authority.

## 6. Experience signals compound
Fast pages, mobile-friendly layouts, and readable formatting reduce bounces and increase engagement. Small experience wins stack up across a whole site.

## 7. Local runs on proximity + proof
For local businesses, rankings follow three things: a complete and active Google Business Profile, consistent name/address/phone data, and a steady flow of genuine reviews.

## 8. Measure what matters
Track rankings for money keywords, organic traffic to key pages, and conversions — not vanity totals. Every strategy file in this skill ends with what to measure.

## 9. Honesty over impressiveness
Never invent metrics. Never promise outcomes. An honest "I don't have that data" beats a fabricated chart every time — with clients and with search engines.

## 10. Business impact orders the work
Fixes are prioritized by expected effect on traffic, leads, or sales — not by how interesting they are technically. Quick high-impact wins always come first.
