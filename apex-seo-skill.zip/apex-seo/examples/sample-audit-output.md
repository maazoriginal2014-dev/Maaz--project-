# Sample Audit Output — Sunflower Bakery (fictional example)

**Site:** sunflowerbakery.example.com (fictional — all data below is illustrative)
**Date:** 2026-10-14
**Prepared for:** Sample Client
**Prepared by:** Apex SEO v1.0.0

> This is a worked example showing the output format. It uses a fictional
> bakery so no real business data is implied.

---

## Executive Summary

Sunflower Bakery's site is small (23 pages) and technically healthy, but it is invisible for the searches that bring in orders: "custom birthday cakes" and "wedding cakes in Springfield" have no dedicated pages, and the homepage title doesn't mention cakes at all. The three highest-impact actions are: create two money pages (birthday cakes, wedding cakes), rewrite the homepage title and H1, and complete the Google Business Profile.

## 1. Technical Audit

| # | Issue | Location | Severity | Effort | Notes |
|---|-------|----------|----------|--------|-------|
| 1 | No XML sitemap submitted | site-wide | High | Quick win | Sitemap exists at /sitemap.xml but was never submitted; submit via Search Console. |
| 2 | Homepage loads slowly on mobile (estimate) | / | Medium | Project | Large hero image (~2MB); compress and serve responsive sizes. |
| 3 | Blog has no category structure | /blog/* | Low | Project | 14 posts in one flat list; add 3 categories. |

## 2. On-Page Audit

| Page | Target keyword | Score | Top 3 fixes |
|------|---------------|-------|-------------|
| / | custom cakes springfield | Weak | Title: "Sunflower Bakery — Custom Cakes in Springfield"; H1 keyword-first; add service links |
| /menu | bakery menu | Needs work | Add descriptive H2s per section; alt text on 8 images |
| /blog/chocolate-cake-tips | chocolate cake tips | Strong | None — use as internal-link source |

**Cannibalization notes:** /cakes and /custom-cakes both target "custom cakes" — merge into /custom-cakes with a redirect from /cakes.

## 3. Content Quality Audit

| URL or group | Issue type | Action | Notes |
|--------------|-----------|--------|-------|
| /blog (posts from 2021-2022) | Outdated | Improve | 6 posts reference old prices; update top 3 by traffic |
| /testimonials | Thin | Improve | 2 sentences; expand with 5 detailed reviews + photos |
| /cakes | Duplicate | Merge | Merge into /custom-cakes (see above) |

## 4. Keyword Opportunities

| Cluster | Primary keyword | Intent | Action |
|---------|----------------|--------|--------|
| birthday cakes | custom birthday cakes springfield | Buy | Create /birthday-cakes/ |
| wedding cakes | wedding cakes springfield | Buy | Create /wedding-cakes/ |
| cake pricing | how much does a custom cake cost | Compare | Create /cake-pricing-guide/ |

## 5. Prioritized Action Plan

### This week
1. Submit sitemap; fix homepage title + H1.
2. Complete Google Business Profile (10 photos, categories, hours).
3. Merge /cakes into /custom-cakes.

### This month
4. Publish /birthday-cakes/ and /wedding-cakes/ pages.
5. Compress homepage hero image; add alt text site-wide.
6. Start review engine: ask every customer, respond within 48h.

### This quarter
7. Publish pricing guide + 4 supporting blog posts; interlink the hub.
8. Refresh 3 outdated blog posts.

## 6. Measurement

Data sources: sitemap extraction (23 URLs), manual page review, owner-provided order data. Search volumes labeled estimates were not used — keyword priorities are based on business value. Baseline: record current rankings for the 3 money keywords and weekly online orders before starting; review at day 30/60/90.
