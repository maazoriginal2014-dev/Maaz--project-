# Keyword Clustering

**Purpose:** Group keywords into topic clusters so each cluster becomes one strong page (or one hub) instead of many weak ones.
**Inputs:** Intent-labeled keyword list.
**Outputs:** Named clusters with a designated primary keyword each.

## Clustering method

1. **Group by shared core term.** Keywords sharing 2+ meaningful words usually belong together ("wedding cake prices", "wedding cake cost", "how much is a wedding cake" → one cluster).
2. **Split by intent.** If a group contains both Learn and Buy keywords, split it — they need different pages.
3. **Name each cluster** after its primary keyword: the shortest, highest-intent term in the group (e.g., cluster "wedding cake prices", primary: "wedding cake prices").
4. **Assign supporting keywords** to each cluster: every other keyword in the group becomes a subtopic, FAQ, or heading on the cluster's page.

## Cluster quality checks
- No cluster with a single keyword (merge it into the closest cluster).
- No cluster larger than 12 keywords (split it — it's really two topics).
- No two clusters sharing the same primary keyword.
- Every Buy keyword sits in its own cluster or with closely related Buy terms only.

## Cannibalization pre-check
- If two clusters could both target the same page on the existing site, flag it now — `keyword-research/keyword-to-page-map.md` resolves it.
- If the site already has two pages that would both fit one cluster, recommend merging (note in the cluster table).

## Output
Table: Cluster name | Primary keyword | Intent | Keyword count | Supporting keywords (comma-separated) | Suggested page type. Aim for 5-15 clusters for a small site, more for large ones.
