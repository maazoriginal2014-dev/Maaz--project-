# Keyword Discovery

**Purpose:** Build a raw keyword list from seed topics, competitor pages, and customer language — without paid keyword tools.
**Inputs:** Seed topics (3-10), niche description, target country, competitor URLs or pasted competitor content (optional but powerful).
**Outputs:** Raw keyword table ready for intent classification.

## Sources to mine (in order)

### 1. Seed expansion
For each seed topic, generate:
- Question forms: "how to [seed]", "what is [seed]", "why [seed]", "[seed] vs [alternative]", "best [seed] for [audience]".
- Modifier forms: "best", "cheap", "near me" (local only), "review", "price", "alternative", "for beginners".
- Long-tail forms: combine seed + audience + problem ("[seed] for small bakeries").

### 2. Competitor page mining
From competitor URLs or pasted content, extract:
- Their H1/H2 headings → these are keyword candidates.
- Their title tags → primary keyword per page.
- FAQ sections → question keywords.
- Category and product names → commercial keywords.

### 3. Customer language mining
- Reviews and testimonials (theirs or competitors'): pull exact phrases customers use.
- Forum/Reddit-style questions in the niche: "how do I...", "anyone know...".
- Support emails or FAQs the business already has.

### 4. Alphabet-soup expansion
For each promising keyword, append a-z mentally ("[keyword] a", "[keyword] b"...) and note natural completions — these reveal real long-tail queries.

## Output table
Columns: Keyword | Source (Seed / Competitor / Customer / Expansion) | Notes.

Aim for 50-100 raw keywords. Do not filter yet — filtering happens in `keyword-research/search-intent.md` and `keyword-research/keyword-clustering.md`.

## Quality checks
- Every keyword must be something a real person would type into Google.
- Drop branded competitor names unless the strategy explicitly targets comparisons.
- Keep a mix: roughly 40% questions, 30% commercial, 30% broad topics.
- Mark any keyword you're unsure is real with "(verify)" — the user can check it in Google's suggestions.
