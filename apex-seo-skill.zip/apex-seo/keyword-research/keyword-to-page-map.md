# Keyword-to-Page Map

**Purpose:** Assign every cluster to exactly one page — existing or to-be-created — eliminating cannibalization.
**Inputs:** Clusters (from keyword-clustering) + site URL inventory (from sitemap extractor).
**Outputs:** Final map: cluster → page → action.

## Steps

### 1. Match clusters to existing pages
For each cluster, find the existing page that best fits (URL, title, and content vs cluster intent).
- Good fit: page already targets the primary keyword and matches intent → action: **Optimize** (send to `audit/on-page-audit.md`).
- Partial fit: page is close but targets something adjacent → action: **Retarget or split** (specify which).
- No fit: no existing page serves this cluster → action: **Create**.

### 2. Resolve conflicts
- Two clusters, one page: the page keeps the stronger-fit cluster; the other gets **Create** (new page) or merges into a related cluster.
- One cluster, two pages: keep the stronger page → **Optimize**; the weaker → **Merge** (301 redirect to the survivor — specify direction).
- No page may own two primary keywords. No keyword may be primary on two pages.

### 3. Prioritize creation order
New pages are built in this order:
1. Buy-intent clusters (money pages first).
2. Compare-intent clusters that support Buy pages.
3. Learn-intent clusters with the clearest ranking path (low competition topics first).

## Output
Table: Cluster | Primary keyword | Assigned page (URL or "NEW") | Action (Optimize / Create / Merge / Retarget) | Priority (1-3). Save as CSV using `templates/keyword-map-template.csv` column order.

This map is the source of truth for `strategy/content-hub-strategy.md` and `strategy/30-60-90-day-plan.md` — every content task traces back to a row here.
