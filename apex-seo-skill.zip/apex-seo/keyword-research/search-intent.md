# Search Intent Analysis

**Purpose:** Classify what the searcher actually wants for each keyword, so pages match intent.
**Inputs:** Keyword list (from keyword-discovery or user's own).
**Outputs:** Intent-labeled keyword table + mismatch warnings for existing pages.

## The three intents

- **Learn** — the searcher wants information. Signals: how, what, why, guide, tips, ideas. Right page: blog post, guide, FAQ.
- **Compare** — the searcher is evaluating options. Signals: best, vs, review, top, alternative, price. Right page: comparison post, review, category page.
- **Buy** — the searcher is ready to act. Signals: buy, order, near me, hire, book, cost of service. Right page: product, service, or location page.

## Classification steps

1. For each keyword, read it aloud as a searcher. What would satisfy you on page one?
2. Label Learn / Compare / Buy. If torn between two, pick the stronger and note the secondary.
3. Flag "split intent" keywords where Google shows mixed results (some guides, some product pages) — these need the dominant format plus elements of the other.

## Intent-to-page rules

- A Learn keyword must never point at a product page as its primary target.
- A Buy keyword must never point at a blog post as its primary target.
- Compare keywords can point at comparison content OR a strong category page — pick one, not both.

## Mismatch check (for existing sites)

For each existing page + its target keyword:
- Does the page format match the keyword's intent? If not, recommend: rewrite the page to match intent, or retarget the page to a keyword its format does serve.
- Record mismatches — they are high-impact fixes in `audit/issue-prioritization.md`.

## Output
Table: Keyword | Intent | Secondary intent (if any) | Right page type | Notes. End with the top 5 "Buy" keywords — these are the money terms the strategy protects first.
