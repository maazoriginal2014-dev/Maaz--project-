# Google Business Profile Optimization

**Purpose:** Maximize visibility in local map results and the local pack.
**Inputs:** Business name, address, phone, website, categories, service area, existing profile access (or screenshots).
**Outputs:** Completed field checklist + 30-day activity plan.

## 1. Foundation fields (complete every one)
- Business name: exact real-world name — no keyword stuffing.
- Primary category: the single closest match (this drives ranking most).
- Secondary categories: add all that genuinely apply (max ~5 relevant).
- Address/service area: storefront → show address; service-area business → hide address, list served areas.
- Phone: one consistent local number (matches website).
- Website link, hours (including holiday hours), and business description (750 chars, natural keyword use, no stuffing).

## 2. Proof assets
- Photos: minimum 10 — exterior, interior, team, products, work in progress. Geotag not required; recency matters.
- Logo + cover photo set correctly.
- Video (30 sec): storefront walkthrough or service in action — high trust signal.

## 3. Reviews engine
- Ask every happy customer; make it frictionless (direct review link / QR at checkout).
- Respond to every review within 48 hours — including positive ones (one genuine line, not templates).
- Never buy reviews, never review-gate (asking only happy customers is fine; suppressing unhappy ones is not).
- Target: steady flow beats bursts. 2-4 new reviews/month minimum.

## 4. Posts and activity (weekly)
- One GBP post per week: offer, event, new product, or tip. Include a photo and CTA button.
- Update hours for holidays immediately — wrong hours destroy trust.
- Add new photos monthly; remove outdated ones.

## 5. Q&A and messaging
- Seed the Q&A section with the 5 questions customers always ask — answer them yourself first.
- Enable messaging if you can reply within a few hours; disable it if you can't.

## 6. Consistency check
- Name, address, phone must match the website footer and contact page exactly.
- Note major directories where the listing should also exist (industry-relevant ones first, not hundreds of spam directories).

## Output
Checklist table: Field | Status (Done / Missing / Fix needed) | Action. Then the 30-day activity plan: week-by-week tasks (photos, posts, review asks). Re-audit quarterly.
