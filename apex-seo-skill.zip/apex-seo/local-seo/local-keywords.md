# Local Keyword Targeting

**Purpose:** Capture "near me" and city-modified searches for local businesses.
**Inputs:** Service list, city/areas served, competitor local pages (optional).
**Outputs:** Local keyword map: keyword → target page.

## 1. Build the local keyword set
For each core service, generate:
- `[service] in [city]` / `[service] [city]`
- `best [service] in [city]`
- `[service] near me` (targets the location page, not a keyword-stuffed page)
- `[service] [neighborhood]` for each major neighborhood served
- Emergency/urgent variants where relevant: `emergency [service] [city]`, `24 hour [service]`

## 2. Page architecture (critical)
- **One location page per city/area served** — never one page stuffed with 20 city names.
- Each location page needs genuinely local content: landmarks served, area-specific FAQs, local photos, embedded map, local reviews.
- Service + city combos: if you offer 5 services in 3 cities, that's up to 15 pages — build the highest-revenue combos first.
- Homepage targets the primary city + brand.

## 3. On-page local signals
Per location page:
- City name in title tag, H1, first paragraph, and at least one H2.
- Full NAP (name, address, phone) in the footer or a contact block — identical to GBP.
- Embedded Google Map.
- Local schema (LocalBusiness subtype) noted for the developer.
- 2-3 locally relevant internal links (to service pages and other location pages).

## 4. What NOT to do
- No doorway pages: thin pages that only swap city names with identical content.
- No fake addresses or virtual offices in cities you don't serve.
- No keyword-stuffed footers listing 50 cities.

## Output
Table: Keyword | Intent | Target page (URL or "NEW: /service-city/") | Priority. Feed new-page rows into `strategy/30-60-90-day-plan.md` in revenue order.
