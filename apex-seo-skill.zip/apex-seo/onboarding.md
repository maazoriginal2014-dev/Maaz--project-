# Onboarding — First-Run Questions

Ask these on first use of the skill for a new site or project. Ask only what is still unanswered; never re-ask answered questions. Maximum three questions per message.

## Required

1. **Website URL** — "What is the website URL you want me to work on?"
2. **Primary goal** — "What is the main goal? (more traffic / more leads / more sales / local customers)"
3. **Target market** — "Which country or city are you targeting?"

## Ask only if relevant

4. **Access level** — "Can you share the sitemap URL (usually yoursite.com/sitemap.xml), paste page content, or upload a URL list? This lets me map the site without paid tools."
5. **Competitors** — "Name 2-3 competitors you want to be compared against." (only for competitor-flavored requests)
6. **Business type** — "Is this a local business with a physical location?" (only if local SEO seems relevant — triggers the local-seo playbooks)
7. **Audience** — "Who is the report for — you, your team, or a client?" (only before reporting; sets the tone per core/output-standards.md)

## After onboarding

1. If a domain was given, run `tools/sitemap_extractor.py` on it, then `tools/url_classifier.py` on the result.
2. Open `core/decision-tree.md` and route to the right playbook.
3. State briefly what you are about to do before doing it.
