# Client Audit Report Builder

**Purpose:** Assemble a complete, client-ready SEO audit document from playbook outputs.
**Inputs:** Completed audit playbooks + prioritized issue list + keyword map (if done).
**Outputs:** Full report following `templates/seo-audit-report-template.md`.

## Build order

1. **Fill the template skeleton** from `templates/seo-audit-report-template.md` — do not invent sections outside it.
2. **Executive summary first (write it last):** 5-8 lines — site health in plain language, the 3 biggest findings, the 3 highest-impact actions. A non-SEO reader must understand it.
3. **Technical findings:** issue table from `audit/technical-audit.md`, already prioritized.
4. **On-page findings:** per-page scorecards from `audit/on-page-audit.md`, worst pages first.
5. **Content findings:** Keep/Improve/Merge/Delete table from `audit/content-quality-audit.md`.
6. **Keyword opportunity snapshot:** top 10 clusters from the keyword map with assigned actions (only if keyword research was run — never pad with invented keywords).
7. **Prioritized action plan:** the This week / This month / This quarter list from `audit/issue-prioritization.md`.
8. **What we measured and how:** one short section stating data sources (sitemap extraction, user-provided data, manual checks) and labeling anything estimated.

## Client-report rules
- No jargon without a one-line explanation on first use.
- Every problem gets its fix in the same section — never a problem list without solutions.
- Screenshots/diagnostics the client provides go in an appendix, referenced inline.
- End with: what happens next (who does what) + when you'll re-check.

## Before sending
Run the self-review: does every claim trace to observed data? Is every estimate labeled? Are there zero outcome guarantees? If any answer is no, fix it before delivery.
