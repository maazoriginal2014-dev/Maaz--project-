# Executive Summary Builder

**Purpose:** A one-page summary for owners and stakeholders who won't read the full audit.
**Inputs:** Completed client audit report (or the underlying findings).
**Outputs:** One page, plain language, decision-ready.

## Structure (do not add sections)

1. **Site health in one line.** E.g., "Your site is technically healthy but losing traffic to thin service pages."
2. **The 3 biggest findings.** One line each — problem + business consequence. No jargon.
3. **The 3 highest-impact actions.** One line each — what to do + what it should achieve (honest framing, no guarantees).
4. **Investment snapshot.** What each action needs: who does it (you / developer / writer) and rough effort (hours or days — estimate, labeled).
5. **What success looks like.** The 3 metrics you'll review in 90 days.

## Rules
- Maximum one page. If it spills over, cut — don't shrink fonts.
- Zero SEO jargon. "Your page titles don't tell Google what the page is about" beats "suboptimal title tag optimization."
- Numbers only if measured or clearly labeled estimates.
- Ends with one question or decision for the owner: approve the plan, pick a start date, or choose between two priorities.
