# Setup — Folder Map and Reading Order

## Folder map

```text
apex-seo/
├── SKILL.md                  ← entry point: identity, router, hard rules
├── _meta.json                ← package metadata
├── MANIFEST.json             ← exact file inventory
├── README.md                 ← what the skill is
├── INSTALL_FOR_AGENTS.md     ← install steps per agent
├── RELEASE_NOTES.md          ← version history
├── onboarding.md             ← first-run questions (this flow)
├── setup.md                  ← this file
├── core/
│   ├── principles.md         ← the SEO beliefs every playbook follows
│   ├── decision-tree.md      ← which playbook for which request
│   └── output-standards.md   ← how every deliverable is formatted
├── audit/
│   ├── technical-audit.md
│   ├── on-page-audit.md
│   ├── content-quality-audit.md
│   └── issue-prioritization.md
├── keyword-research/
│   ├── keyword-discovery.md
│   ├── search-intent.md
│   ├── keyword-clustering.md
│   └── keyword-to-page-map.md
├── local-seo/
│   ├── google-business-profile.md
│   └── local-keywords.md
├── strategy/
│   ├── 30-60-90-day-plan.md
│   └── content-hub-strategy.md
├── reporting/
│   ├── client-audit-report.md
│   └── executive-summary.md
├── templates/
│   ├── keyword-map-template.csv
│   ├── issue-log-template.csv
│   ├── page-brief-template.md
│   └── seo-audit-report-template.md
├── tools/
│   ├── sitemap_extractor.py
│   ├── url_classifier.py
│   └── check_environment.py
└── examples/
    └── sample-audit-output.md
```

## Reading order for the agent

1. `SKILL.md` — identity, runtime rule, router, hard rules.
2. `setup.md` — this map (so the agent knows what exists).
3. `onboarding.md` — first-run questions.
4. `core/principles.md` — the beliefs behind every recommendation.
5. `core/decision-tree.md` — pick the playbook for the current request.
6. The routed playbook file(s) — follow them step by step.
7. `core/output-standards.md` — format the deliverable.

## Rules for playbook files

- Each playbook is standalone: it states its own inputs, steps, and output format.
- Playbooks reference each other by relative path only when one is a genuine prerequisite.
- Templates are blank and fillable; examples are filled-in and fictional.
- Tools use only the Python standard library so they run anywhere.
