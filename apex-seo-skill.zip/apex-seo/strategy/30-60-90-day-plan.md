# 30-60-90 Day SEO Plan

**Purpose:** Turn audit findings and keyword maps into a phased execution roadmap.
**Inputs:** Prioritized issue list (`audit/issue-prioritization.md`) + keyword-to-page map + business goal.
**Outputs:** Three-phase plan with owners, effort, and success metrics per phase.

## Phase 1 — Days 1-30: Fix and stabilize
Goal: remove everything blocking performance.

Include:
- All Critical and High technical issues (indexation, HTTPS, redirects, sitemap).
- Quick-win on-page fixes on money pages (titles, H1s, meta descriptions).
- Google Business Profile completion (if local).
- Set up measurement: rank tracking method (manual or tool), traffic baseline, conversion baseline. Record the baseline numbers — the plan is judged against them.

Success metric: zero Critical issues remaining; money pages pass the on-page checklist.

## Phase 2 — Days 31-60: Build relevance
Goal: publish the content that captures demand.

Include:
- New Buy-intent pages from the keyword map (highest priority first).
- On-page optimization of existing pages per `audit/on-page-audit.md`.
- Internal linking overhaul: pillar pages get the most internal links with varied anchors.
- Content improvements from `audit/content-quality-audit.md` (top 5 "Improve" actions).
- GBP weekly posts + review engine running (if local).

Success metric: all Buy clusters have an assigned, optimized page; internal linking map implemented.

## Phase 3 — Days 61-90: Expand authority
Goal: widen topical coverage and earn trust signals.

Include:
- Compare and Learn cluster content (supporting articles linking to pillars).
- Content hub internal linking completed (`strategy/content-hub-strategy.md`).
- Freshness updates on outdated top performers.
- Review/refresh cycle: re-run the technical audit, confirm fixes held.

Success metric: full hub structure live; measurable movement on target keywords vs baseline (report honestly — some terms take longer).

## Plan format
Table per phase: Task | Owner (user / developer / writer) | Effort | Depends on | Done when.

End with: **What we measure** — the 3-5 metrics reviewed at day 30, 60, and 90 (rankings for money keywords, organic sessions to key pages, conversions/leads). And **What we don't promise** — one line restating no outcome guarantees.
