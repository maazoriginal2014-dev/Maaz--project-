# Content Hub Strategy

**Purpose:** Build pillar + cluster architecture that earns topical authority.
**Inputs:** Keyword clusters (`keyword-research/keyword-clustering.md`) + keyword-to-page map.
**Outputs:** Hub blueprint: pillars, clusters, internal linking rules.

## 1. Define pillars
- Each pillar = one broad topic the business must own (usually 3-6 pillars for a small site).
- Pillar page: comprehensive guide (2,000+ words), targets the broad head term, Learn intent.
- Pillar selection rule: must map to a real revenue area — no vanity pillars.

## 2. Attach clusters
- Each cluster from keyword-clustering becomes 1 article under its pillar.
- Cluster article: 800-1,500 words, targets the cluster's primary keyword, answers it completely.
- Every cluster article links UP to its pillar with descriptive anchor text.
- The pillar links DOWN to every cluster article (a curated "in this guide" section, not a link dump).

## 3. Cross-linking rules
- Cluster articles link sideways to each other only when genuinely related (max 2-3 per article).
- No orphan articles: every new URL gets at least one internal link from an indexed page on publish day.
- Anchor text varies: exact-match anchors max 30%, the rest partial/phrase/natural.

## 4. Hub page anatomy (pillar)
1. H1 with the head term.
2. Intro answering the core question in 2-3 sentences.
3. Jump-link table of contents.
4. H2 per major subtopic (each = one cluster article, summarized in 100-150 words + link).
5. FAQ section (targets question keywords, FAQ schema noted).
6. CTA relevant to the business goal.

## 5. Build order
1. Pillar with the most Buy-adjacent clusters first.
2. Its clusters, highest-priority first.
3. Internal links added as each piece publishes — never "later."
4. Next pillar only after the first hub is fully interlinked.

## Output
Blueprint table: Pillar | Pillar URL (existing or NEW) | Clusters under it | Build order. Plus the internal linking checklist the writer/developer follows per article.
