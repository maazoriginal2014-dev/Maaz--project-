# Page Brief

## Target
- **URL (new or existing):**
- **Primary keyword:**
- **Search intent:** Learn / Compare / Buy
- **Page type:** Blog post / Guide / Product / Service / Category / Location

## Searcher promise
In one sentence, what will the searcher get from this page that page-one results don't give as well?

## Title & meta
- **Title tag (≤60 chars):**
- **Meta description (150-155 chars):**
- **URL slug:**

## Outline
- H1:
- H2:
- H2:
- H2:
- (add rows as needed)

## Questions to answer (FAQ)
1.
2.
3.

## Internal links
- Link to (URL) with anchor text:
- Link to (URL) with anchor text:
- Link to (URL) with anchor text:

## Media & proof
- Images needed:
- Original data / photos / quotes to include:

## Notes for writer
- Tone:
- Word count target:
- Things to avoid:
