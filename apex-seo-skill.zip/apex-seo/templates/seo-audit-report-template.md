# SEO Audit Report

**Site:**
**Date:**
**Prepared for:**
**Prepared by:** Apex SEO v1.0.0

---

## Executive Summary
(5-8 lines: site health in plain language, 3 biggest findings, 3 highest-impact actions.)

## 1. Technical Audit
### 1.1 Crawlability & indexation
### 1.2 Site structure
### 1.3 Page experience
### Issue table
| # | Issue | Location | Severity | Effort | Notes |

## 2. On-Page Audit
### Per-page scorecards
| Page | Target keyword | Score (Strong / Needs work / Weak) | Top 3 fixes |
### Cannibalization notes

## 3. Content Quality Audit
| URL or group | Issue type | Action (Keep / Improve / Merge / Delete) | Notes |

## 4. Keyword Opportunities
(top clusters with assigned page actions — only if keyword research was run)

## 5. Prioritized Action Plan
### This week
### This month
### This quarter

## 6. Measurement
(Data sources used, baseline metrics, what gets reviewed at day 30/60/90. Estimates labeled.)

## Appendix
(Client-provided diagnostics, screenshots, raw data references.)
