#!/usr/bin/env python3
"""Apex SEO — check_environment.py
Verifies the Python runtime meets the skill's requirements.
The Apex SEO tools use only the standard library, so this just
checks the Python version and that key modules import cleanly.
"""
import sys


REQUIRED = (3, 8)
MODULES = ["urllib.request", "urllib.parse", "xml.etree.ElementTree", "re", "json", "csv"]


def main():
    ok = True
    ver = sys.version_info
    print("Python %d.%d.%d" % (ver.major, ver.minor, ver.micro))
    if (ver.major, ver.minor) < REQUIRED:
        print("FAIL: Python %d.%d+ required" % REQUIRED)
        ok = False
    else:
        print("OK: Python version meets requirement (>= %d.%d)" % REQUIRED)

    for mod in MODULES:
        try:
            __import__(mod)
            print("OK: module '%s' available" % mod)
        except ImportError:
            print("FAIL: module '%s' missing" % mod)
            ok = False

    # Self-check: the sibling tools must at least compile
    import py_compile
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    for tool in ("sitemap_extractor.py", "url_classifier.py"):
        path = os.path.join(here, tool)
        try:
            py_compile.compile(path, doraise=True)
            print("OK: %s compiles" % tool)
        except py_compile.PyCompileError as e:
            print("FAIL: %s does not compile: %s" % (tool, e))
            ok = False

    print()
    print("Environment check: %s" % ("PASS" if ok else "FAIL"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
