#!/usr/bin/env python3
"""Apex SEO — sitemap_extractor.py
Fetches a site's sitemap (or sitemap index) and lists every URL found.
Standard library only. Usage:
    python3 sitemap_extractor.py https://example.com [output.txt]
If no sitemap path is given, tries /sitemap.xml then /sitemap_index.xml.
"""
import sys
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET


def fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "ApexSEO/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def extract_urls(xml_bytes):
    """Return (page_urls, nested_sitemap_urls) from sitemap XML."""
    root = ET.fromstring(xml_bytes)
    pages, sitemaps = [], []
    for child in root:
        ctag = child.tag.split("}")[-1]
        for sub in child:
            stag = sub.tag.split("}")[-1]
            if stag == "loc" and sub.text:
                if ctag == "sitemap":
                    sitemaps.append(sub.text.strip())
                elif ctag == "url":
                    pages.append(sub.text.strip())
    if not pages and not sitemaps:
        # Fallback: treat every loc as a page URL
        for elem in root.iter():
            if elem.tag.split("}")[-1] == "loc" and elem.text:
                pages.append(elem.text.strip())
    return pages, sitemaps


def get_all_urls(domain):
    domain = domain.rstrip("/")
    candidates = [domain + "/sitemap.xml", domain + "/sitemap_index.xml"]
    tried = []
    for sm_url in candidates:
        try:
            data = fetch(sm_url)
        except (urllib.error.URLError, OSError) as e:
            tried.append("%s (%s)" % (sm_url, e))
            continue
        pages, nested = extract_urls(data)
        all_pages = list(pages)
        for n in nested:
            try:
                p2, _ = extract_urls(fetch(n))
                all_pages.extend(p2)
            except (urllib.error.URLError, OSError, ET.ParseError):
                continue
        # de-duplicate, keep order
        seen, unique = set(), []
        for u in all_pages:
            if u not in seen:
                seen.add(u)
                unique.append(u)
        return unique, sm_url
    return [], None


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 sitemap_extractor.py https://example.com [output.txt]")
        sys.exit(1)
    domain = sys.argv[1]
    if not domain.startswith("http"):
        domain = "https://" + domain
    urls, source = get_all_urls(domain)
    if source is None:
        print("No sitemap found. Tried /sitemap.xml and /sitemap_index.xml")
        sys.exit(2)
    print("Source: %s" % source)
    print("URLs found: %d" % len(urls))
    out = sys.argv[2] if len(sys.argv) > 2 else None
    if out:
        with open(out, "w", encoding="utf-8") as f:
            f.write("\n".join(urls) + "\n")
        print("Saved to %s" % out)
    else:
        for u in urls:
            print(u)


if __name__ == "__main__":
    main()
