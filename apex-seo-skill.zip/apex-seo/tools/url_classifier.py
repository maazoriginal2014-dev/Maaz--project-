#!/usr/bin/env python3
"""Apex SEO — url_classifier.py
Classifies URLs from a list as blog / product / category / page / other.
Usage:
    python3 url_classifier.py urls.txt
    cat urls.txt | python3 url_classifier.py
Prints a summary table plus the classified list.
"""
import sys
import re
from urllib.parse import urlparse


BLOG_SEGMENTS = {"blog", "news", "article", "articles", "post", "posts",
                  "insights", "insight", "journal"}
PRODUCT_SEGMENTS = {"product", "products", "shop", "item", "items", "p"}
CATEGORY_SEGMENTS = {"category", "categories", "collection", "collections",
                     "topic", "topics"}


def classify(url):
    path = urlparse(url).path or "/"
    segs = [s.lower() for s in path.strip("/").split("/") if s]
    if any(s in BLOG_SEGMENTS for s in segs):
        return "blog"
    # Dated paths like /2024/05/slug are almost always blog posts
    if re.search(r"/20\d\d/\d\d?/", path):
        return "blog"
    if any(s in PRODUCT_SEGMENTS for s in segs):
        return "product"
    if any(s in CATEGORY_SEGMENTS for s in segs):
        return "category"
    if len(segs) <= 1:
        return "page"
    return "other"


def main():
    if len(sys.argv) > 1 and sys.argv[1] != "-":
        with open(sys.argv[1], encoding="utf-8") as f:
            urls = [l.strip() for l in f if l.strip()]
    else:
        urls = [l.strip() for l in sys.stdin if l.strip()]

    results = [(u, classify(u)) for u in urls]
    counts = {}
    for _, label in results:
        counts[label] = counts.get(label, 0) + 1

    print("URL classification summary (total %d):" % len(results))
    for label in ("page", "blog", "product", "category", "other"):
        if label in counts:
            print("  %-8s %d" % (label, counts[label]))
    print()
    print("url,classification")
    for u, label in results:
        print("%s,%s" % (u, label))


if __name__ == "__main__":
    main()
